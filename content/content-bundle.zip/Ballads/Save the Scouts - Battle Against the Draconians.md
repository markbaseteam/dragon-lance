---
tags: Ballad
---

"The Battle Against the Draconians"

Verse 1:
Along a game trail in the north,
The adventurers did set forth,
Towards the sounds of Draconian's calls,
With weapons drawn and ready for brawls.

Chorus:
With Vin leading the way,
They marched to face their prey,
And as the creatures neared,
The adventurers prepared.

Verse 2:
Bink tried to sneak and take the lead,
But fell into a sinkhole, what a deed!
The Draconians heard the sound,
And to the battle they were bound.

Chorus:
With Vin leading the way,
They marched to face their prey,
And as the creatures neared,
The adventurers prepared.

Verse 3:
A Kapak Draconian flapped around,
As Dag and Gerald stood their ground.
Javelins thrown, and swords did gleam,
The battle had just started, it would seem.

Chorus:
With Vin leading the way,
They marched to face their prey,
And as the creatures neared,
The adventurers prepared.

Verse 4:
Bink cast spells from high above,
While Dag and Gerald showed their love.
For the art of combat, and the thrill of the fight,
Their enemies' fates were sealed, that was right.

Chorus:
With Vin leading the way,
They marched to face their prey,
And as the creatures neared,
The adventurers prepared.

Verse 5:
The Kapak sneaked up with a grin,
But Bink cast a spell, and it did spin.
Chromatic orb, with lightning's might,
Defeated the Kapak, in the dead of night.

Chorus:
With Vin leading the way,
They marched to face their prey,
And as the creatures neared,
The adventurers prepared.

Verse 6:
The Baaz fought on with all their might,
But Dag, Gerald, and Vin were not to be denied.
With greataxe, sword, and magic spells,
The Draconians were defeated, and all was well.

Chorus:
With Vin leading the way,
They marched to face their prey,
And as the creatures neared,
The adventurers prepared.

Outro:
And so, the battle was won,
With Bink, Dag, Gerald, and Vin.
And as they looked upon their foes,
They knew that their victory was close.