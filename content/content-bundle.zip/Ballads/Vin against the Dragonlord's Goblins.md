---
tags: Ballad
---

Verse 1: 
The adventurers rode out with purpose and might, 
To face a foe they'd encountered in the night. 
With weapons at the ready and courage in their hearts, 
They rode to face the goblin horde that played their evil parts.

Chorus: 
Oh the battle with the goblins and hobgoblin was fought, 
With bravery and valor, and a plan that couldn't be caught. 
With Vin the hero at the lead, and his companions at his side, 
They fought until the very end, with courage that wouldn't hide.

Verse 2: 
The goblins and the hobgoblin, with their weapons and their hate, 
Attacked the adventurers with a force that couldn't be tamed. 
But Vin and his companions, they stood strong and they stood tall, 
And they battled with a ferocity that defeated them all.

Chorus: 
Oh the battle with the goblins and hobgoblin was fought, 
With bravery and valor, and a plan that couldn't be caught. 
With Vin the hero at the lead, and his companions at his side, 
They fought until the very end, with courage that wouldn't hide.

Verse 3: 
And when the battle was over, and the dust had cleared, 
The adventurers stood victorious, without any fear. 
With the goblin horde defeated, and the hobgoblin in its place, 
They rode back to their city, with a smile upon each face.

Chorus: 
Oh the battle with the goblins and hobgoblin was fought, 
With bravery and valor, and a plan that couldn't be caught. 
With Vin the hero at the lead, and his companions at his side, 
They fought until the very end, with courage that wouldn't hide.

Outro: 
So let us sing of Vin the hero, and his companions so true, 
For they battled with the goblins and hobgoblin, and they won anew. 
And may their tale of bravery, never be forgotten or untold, 
For they fought with courage, and they triumphed, with hearts of gold.