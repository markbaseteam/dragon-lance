---
aliases: Captain Hask
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Captain Hask

```ad-danger
Cool description
```

Writeup

![](https://i.imgur.com/xy4Cr4f.png)

Lighning on death.