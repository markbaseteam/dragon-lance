---
aliases: Marshal Vendri
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Marshal Vendri

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
Marshal of [[Kalaman]] 