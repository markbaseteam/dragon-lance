---
aliases: Nesra
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Nesra

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
