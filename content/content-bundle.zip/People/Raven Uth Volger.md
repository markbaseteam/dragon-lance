---
aliases: Raven Uth Volger
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Raven Uth Volger

```ad-danger
Cool description
```

Mayor of Vogler

![](https://i.imgur.com/pIzWGS7.png)

