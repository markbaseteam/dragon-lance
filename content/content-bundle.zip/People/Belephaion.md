---
aliases: Belephaion
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Belephaion

```ad-danger
Cool description
```

Bad guy leading one of Takhisis army. Voice of [[Takhisis]]

Hates [[Lohezet]] 

Insert Cool Pic
