---
aliases: Lord Bakaris Uth Estide, Asshole the Elder, Lord Bakaris
tags: NPC/Dragonlance, Creature/Humanoid/Human
Creature_Type: Humanoid/Human 
location: Vogler
---
# Lord Bakaris Uth Estide

```ad-danger
Cool description
```

An asshole as well.

![](https://i.imgur.com/jkevjvA.png)
