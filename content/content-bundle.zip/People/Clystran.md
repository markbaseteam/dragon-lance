---
aliases: Clystran
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Clystran

```ad-danger
Cool description
```

Meet him in the [[Northern Wastes]] 

![](https://i.imgur.com/PPr8KZr.png)

