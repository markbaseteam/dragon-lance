---
aliases: Sir Sarlamir, Zanas Sarlamir
tags: NPC/Dragonlance, Creature/Undead
Creature_Type: Undead
location: 
---
# Sir Sarlamir

```ad-danger
Cool description
```

![](https://i.imgur.com/y5igwh4.png)

[[Knight Jandin]] journey with him. But they lied and were cursed.

Cursed Dragonlance. She lied about his role.

### Salamir's Story
Among the dead entombed beneath Castle Kalaman lies the body of Knight Zanas Sarlamir. A respected knight of the Order of the Crown, Sarlamir received a divine quest from the god Paladine years before the Cataclysm. Paladine told him the Kingpriest of Istar had created a magical wonder in the east—a flying city (detailed in chapter 6)—and in so doing, the kingpriest had enraged the metallic dragons that had long remained hidden on Krynn. Paladine tasked Sarlamir with going to this flying city, assuaging the dragons’ fury, and convincing the kingpriest to return the city to the land. Sarlamir agreed. The knight knew his task was daunting, though, and decided to hedge his bets. He took his family’s greatest treasure with him: an ancient dragonlance.

Sarlamir and his fellow knights reached the kingpriest’s flying city and stood before a flight of righteously furious metallic dragons. When the kingpriest refused to land the flying city, the dragons refused to leave. As the conflict escalated, Sarlamir used his dragonlance to slay the dragons’ leader, the gold dragon Karavarix. As soon as Karavarix’s blood touched the dragonlance, the weapon rusted away in Knight Sarlamir’s hand. The dragons attacked, slaying Sarlamir and crashing the flying city.
A handful of Sarlamir’s loyal knights escaped, and they brought his body and his cursed dragonlance back to Kalaman. Both were interred beneath the city, where they remained.




