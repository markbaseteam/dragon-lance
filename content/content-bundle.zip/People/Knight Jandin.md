---
aliases: Knight Jandin
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Knight Jandin

```ad-danger
Cool description
```

Fought in the time of the [[Cataclysm]]. Deep in the Castle in [[Kalaman]]. 

Quested with [[Sir Sarlamir]] 

### Knight Jandin's Shame
*When Jandin returned Sarlamir’s body to Kalaman, she twisted the truth, reporting Sarlamir died defending people from rampaging evil dragons. Sarlamir was entombed a hero.

*Jandin regrets this, knowing Sarlamir’s disobedience and deeds contributed to the gods’ disfavor—and ultimately to the Cataclysm. She believes herself complicit in her fellow knight’s disgrace.

*She asks the characters to take the weapon entombed with Sarlamir in the next chamber. Perhaps in their hands, it can find redemption and the gods’ favor.

*The flames blazing through the tombs are fire from the Cataclysm. They used to be confined to Sarlamir’s tomb, but now they run rampant. Jandin doesn’t know why (she’s unaware of Lord Soth’s presence).



