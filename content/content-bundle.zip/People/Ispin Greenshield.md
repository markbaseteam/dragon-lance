---
aliases: Ispin Greenshield
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: Humaniod-Human
location: 
---
# Ispin Greenshield

```ad-danger
Cool description
```

Writeup

Good natured adventurer from [[Solamnia]]. Ispen took his name a distinctive green shield he found early in his adventuring career. Ispen took his name a distinctive green shield he found early in his adventuring career. He claimed it was magical, but it had no obvious magical properties. The bighearted Ispin loved telling tall tales of his travels to anyone who would listen.

Ispin used to travel with a human Knight of Solamnia named Becklin and a hill dwarf warrior named Cudgel. These two featured in many of Ispin's stories of fighting sea monsters and goblin raiders. Ispen retired from travelling years ago, becoming a permanent resident of a little known village in Solamnia called Vogler.

The characters all recall hearing Ispin's story of being given the green shield by a unicorn in the far-off forest of Darken Wood. None can say if this is true or another of Ispin's tall tales.

