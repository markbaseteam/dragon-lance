---
aliases: Fewmaster Gholcag
tags: NPC/Dragonlance, Creature/Humanoid/Giant/Ogre
Creature_Type: Humanoid/Giant/Ogre
location: 
---
# Fewmaster Gholcag

```ad-danger
She's a beauty!
```

Writeup

Insert Cool Pic
![](https://i.imgur.com/E4Ofqex.png)

![](https://i.imgur.com/AwrrU32.png)
