---
aliases: Bakaris Uth Estide, Asshole the Younger
tags: NPC/Dragonlance, Creature/Humanoid/Human
Creature_Type: Humanoid/Human 
location: Volger
---


# Bakaris Uth Estide

```ad-danger
Cool description
```

A real asshole. A noble in [[Vogler]].


![](https://i.imgur.com/TXQB1M9.png)
