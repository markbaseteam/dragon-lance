---
aliases: Darrett Highwater
tags: NPC/Dragonlance, Creature/Humanoid/Human
Creature_Type: Humanoid/Human 
location: 
---
# Darrett Highwater

```ad-danger
“Good morning, Becklin’s friends,” comes a cheerful voice. “I’m glad I caught you.” From a shop doorway steps a young man, no more than twenty years old. He has a sword at his hip and a cloth sack in his arm. “I’m Darrett, Becklin’s student. I hope you haven’t had breakfast already.”
```

Studies under [[Becklin Uth Viharin]]

![](https://i.imgur.com/8rPIvqI.png)

- Personality Trait. “My mind sometimes works faster than I can talk, and I often second-­guess myself.”
- Ideal. “My honor is my life.”
- Bond. “As Becklin’s student, I’m trying to learn everything I can from such a hero.”
- Flaw. “Though I understand military strategy, I’m inexperienced at command and have a hard time delegating.”

### A Maturing Darrett
![](https://i.imgur.com/npPY2AS.png)

Darrett continues to grow and is becoming quite the leader. Vin even compliments him on it. 