---
aliases: Dalamar
tags: NPC/Dragonlance, Creature/Humanoid/Elf/Silvanesti
Creature_Type: Humanoid/Elf/Silvanesti
location: 
---
# Dalamar

```ad-danger
Cool description
```

In [[Wrecker’s Edge]], looking for pre-Cataclasym ruins. Knows the location of the [[City of Lost Names]].

(later in the books, becomes a big deal as a black robe wizard)

In talking with him, we get the fell of him.
- Personality Trait. “Everybody wants something. I’m certain we can help one another.” 
- Ideal. “Magic is meant to be used.”
- Bond. “I’ll do anything to recover my home.” 
- Flaw. “I’m overconfident, sometimes to the point of putting myself or others in danger.”





















![](https://i.imgur.com/GasxAbI.png)