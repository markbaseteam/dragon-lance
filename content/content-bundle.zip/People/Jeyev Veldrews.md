---
aliases: Jeyev Veldrews
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Jeyev Veldrews

```ad-danger
Cool description
```

Mercenary in [[Ironclad Regiment]], which is run by [[Cudgel Ironsmile]].

![](https://i.imgur.com/QZC3YnF.png)

