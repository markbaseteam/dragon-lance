---
aliases: Lord Soth
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Lord Soth

```ad-danger
Cool description
```

Writeup

![](https://i.imgur.com/W2ud3qj.png)
