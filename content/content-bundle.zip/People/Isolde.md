---
aliases: Isolde
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Isolde

```ad-danger
Cool description
```

She caused [[Lord Soth]]'s fall. Love causes one to fall tot he dark side.

![](https://i.imgur.com/W2ud3qj.png)
