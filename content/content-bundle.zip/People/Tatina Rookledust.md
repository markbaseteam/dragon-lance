---
aliases: Tatina Rookledust
tags: NPC/Dragonlance, Creature/Humanoid/Gnome/Tinker
Creature_Type: Humanoid/Gnome/Tinker 
location: 
---
# Tatina Rookledust

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
