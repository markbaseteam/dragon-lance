---
aliases: Cudgel Ironsmile
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Cudgel Ironsmile

```ad-danger
Cool description
```

Adventuring companion of [[Ispin Greenshield]] and [[Becklin Uth Viharin]]. Runs a mercenary group.

![](https://i.imgur.com/dQNbnTQ.png)
