---
aliases: Lohezet
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Lohezet

```ad-danger
Cool description
```

Lohezet is a scheming, black-robed Mage of High Sorcery. He’s obsessed with ancient magic and venomous beasts, and his research led the Dragon Army to the City of Lost Names.

Hates [[Belephaion]] 

Insert Cool Pic
