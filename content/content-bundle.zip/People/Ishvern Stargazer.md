---
aliases: Ishvern Stargazer
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: Humanoid/Elf/Sea 
location: 
---
# Ishvern Stargazer

```ad-danger
Cool description
```

Writeup

![](https://i.imgur.com/Ljtdhmb.png)

