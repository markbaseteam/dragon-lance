---
aliases: Dragon Highmaster Kansaldi Fire-Eyes
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Dragon Highmaster Kansaldi Fire-Eyes

```ad-danger
Cool description
```

Harbard the [[Kalaman]] scout tells us
- Dragon Army has split forces to attack communities across Hinterlund and Nightlund 
- They are intent on isolation Kalaman from the Solamnic cities of Maelgoth and Palanthas in the west
- The leader of the army is named [[Dragon Highmaster Kansaldi Fire-Eyes]]

Insert Cool Pic
