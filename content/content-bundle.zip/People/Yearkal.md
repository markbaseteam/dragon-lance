---
aliases: Yearkal
tags: NPC/Dragonlance, Creature/Elf/Sea
Creature_Type: Elf/Sea
location: 
---
# Yearkal

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
