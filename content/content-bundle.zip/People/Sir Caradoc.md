---
aliases: Sir Caradoc
tags: NPC/Dragonlance, Creature/Undead/Wight
Creature_Type: Undead
location: Kalaman  
---
# Sir Caradoc

```ad-danger
Cool description
```

A [[Knights of Solomnia]] , Order of the Rose. But there is something very wrong - worn armor and tattered banner. Old plate armor.

![](https://i.imgur.com/7k9Uonn.png)


Post Killing
![](https://i.imgur.com/ovrVN7o.png)

