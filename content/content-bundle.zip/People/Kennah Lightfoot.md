---
aliases: Kennah Lightfoot
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Kennah Lightfoot

```ad-danger
Cool description
```

Writeup

Kender. She is from Hearts Hollow in the [[Northern Wastes]] 
