---
aliases: Wersten Kern
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Wersten Kern

```ad-danger
Cool description
```

Right shriveled hand of [[Lord Soth]] 

![](https://i.imgur.com/SgBm7gD.png)

