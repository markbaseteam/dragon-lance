---
aliases: Virruza
tags: NPC/Dragonlance, Creature/Sload/Green
Creature_Type: Sload/Green
location: 
---
# Virruza

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
