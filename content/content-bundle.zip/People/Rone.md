---
aliases: Rone
tags: NPC/Dragonlance, Creature/Human
Creature_Type: Human
location: 
---
# Rone

```ad-danger
Cool description
```

Writeup

Insert Cool Pic
