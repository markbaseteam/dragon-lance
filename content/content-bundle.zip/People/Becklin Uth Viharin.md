---
aliases: Becklin Uth Viharin
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: Humanoid/Human
location: Vogler
---
# Becklin Uth Viharin

```ad-danger
Cool description
```

Becklin Uth Viharin, Knight of the Crown. She was a common travelling companion of [[Ispin Greenshield]] and [[Cudgel Ironsmile]]. She is the Castillion of the local keep.

![](https://i.imgur.com/fZJRDfy.png)
