---
aliases: Zhelsuel
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Zhelsuel

```ad-danger
Cool description
```

Leader of the elven expedition to the [[Northern Wastes]] 

- Personality Trait. “I know what’s best for my people, and I lead with logic and precision.”
- Ideal. “I take pride in work done to perfection.”
- Bond. “I’ll show my people what I can do. My name won’t be forgotten.”
- Flaw - Bitter

[[Silvanesti]] elf.