---
aliases: Leedara
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: 
location: 
---
# Leedara

```ad-danger
Cool description
```

A blue Elf Singer

![](https://i.imgur.com/yHpjCz4.png)

