---
aliases: Governor Calof Miat
tags: NPC/Dragonlance, Creature/<% tp.frontmatter.Creature_Type %>
Creature_Type: Humanoid/Human 
location: Kalaman
---
# Governor Calof Miat

```ad-danger
Cool description
```

Writeup

Governor of [[Kalaman]]
