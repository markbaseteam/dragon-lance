[[Ispin Greenshield]] old shield

Becklin reenters the room carrying a shallow wooden box, approximately three feet to a side. She sets it down gently on a table. “Ispin left this for all of you,” she explains. “But it comes with a condition. Since he won’t be attending the Kingfisher Festival this year, he wanted you all to participate for him. Specifically, he hoped you’d take his place during the reenactment of the Battle of High Hill. Every year, he looked forward to participating—and dying—in an even more ludicrous way than the year before.”

![](https://i.imgur.com/PJimSYA.png)


For reference, adventurers all recall hearing Ispin's story of being given the green shield by a unicorn in the far-off forest of Darken Wood. None can say if this is true or another of Ispin's tall tales. Gerald received the shield in exchange for the hero's participating in the the town of Vogler's Kingfisher festival. Note that Vin did the best at fishing of the group.