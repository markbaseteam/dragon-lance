![](https://i.imgur.com/WLVgFwR.jpg)

Range 18 miles.