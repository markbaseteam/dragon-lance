---
date: 2023-01-27
tags: Session/Dragonlance
---
# SDQ 05 - Rookledust 
**Date:** 2023-01-27
**Location:** Kalaman
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker|Bink]] - [[Lonnie]] 

## Events
*The walled city of Kalaman rises in the distance, spreading across the southern shore of a wide bay. Ships sail to and from the city’s walled harbor, their courses lit by a pair of towering beacons.*

Talwin arrived in [[Kalaman]]  before us (saved the town), but met Bink on the way. On the shore ahead, where the Vingaard River meets Kalaman Bay, dozens of survivors from Vogler have pulled their mismatched boats ashore and ­begun making camp.

[[Bakaris Uth Estide]] and his father [[Lord Bakaris Uth Estide]] , who were on the boats, are missing. [[Raven Uth Volger]] eventually catches up with us and says they went ahead to the city. She is concerned. Make contact with the city leaders for more reasonable accommodations. 

*Statues of titanic soldiers line Kalaman’s mighty walls. These ancient stone knights stare into the distance, daring invaders to dash themselves against defenses that withstood even the Cataclysm. A disorganized neighborhood of tents and ramshackle structures lines the road to the city’s nearest gate, where soldiers in blue-and-yellow uniforms question all who enter.*

![[Kalaman#Castle Kalaman]]

Asshole the Younger is there. We push back.

Eight serious-looking people sit around a broad table in the middle of a spacious hall. At the table’s end, a tall man with plaited blond hair and a velvet vest of blue and gold stands to greet you.

“Welcome, guests. I’m [[Governor Calof Miat]]. Your leader has briefed us on the situation in Vogler, his bold defense, and his eagerness to strike back against these invaders.” As Miat says this, he nods to a man near him—Lord Bakaris, who glares at your intrusion.

“Tell us,” the governor continues, “are your people still preparing for battle?”

We upon the Governor on the real situation. Governor Miat frowns. “This is all dire news. My heart goes out to your friends and families, but I hope you can understand our reticence to welcome you all through our city’s gates. These aren’t normal times. Marshal?”

The governor gestures to a stern woman wearing armor embellished with the blue and gold colors of Kalaman. She nods and begins, “I am [[Marshal Vendri]], commander of Kalaman’s military forces. I’m afraid your situation is far from unique.”
- Small villages and farms to the south and east of Kalaman have been burned in recent weeks.
- Vogler is the largest community to be attacked and the only one with many survivors.
- Experienced patrols of armored Kalaman soldiers have been found cut down, in some cases with mysterious clawlike gashes in their armor. 
- Lord Bakaris and the characters have provided the clearest information on the enemy that Kalaman has received to date.

They will help the Voglers in exchange for us becoming special forces for the city. 


### First Mission - Gnome Info on Dragon Machine
Go to [[Tatina Rookledust]] to find out about the [[Boilerdrake]]. If can, bring back as an advisor. Get first week pay - 5 gold. 

![](https://i.imgur.com/DJZP7H2.png)


On the way, run into a Kender name Trapspringer that is looking for Dragons. Talwin engages.

#### Rookledust 
*On a hill stands an unusual structure that resembles both a cottage and a metal fortress. The building bristles with steaming pipes and whirring devices, and it is currently under siege.*

*Amid clanging metal contraptions, goblins try to breach the structure, impeded by gadgets that spin, snap, and thrash in the yard. Every few moments, a gnome appears from an open clockface above the door and hucks a new clockwork calamity at the attackers while cackling and yelling insults.*

![](https://i.imgur.com/VM365oz.jpg)

##### Battle commences.

**Jeff's mere Human version**
Talwin, enamored by all the excitement, tosses Fairy Fire onto some of the goblins. Vin comes forward and knocks the glitter out of one of the goblins. Dag, angered by all the silliness, rages and tosses a javelin. [[Goblin]]s fire bows at us, one rather nasty on Dag. One shot on Talwin drops his concentration. A Goblin rushes forward and Vin skewers him (crit). Vin get nicked up in the fight. Bink launches a Firebolt at a goblin, misses. Gerald comes forward and punctures the lung of a goblin, and heals Talwin. A [[Hobgoblin]] shoots and arrow in our general direction. Some of the clockwork creatures amble by us. 

Talwin tosses more fairy fire onto the goblins, but it only illuminates one of them. Vin chops him in twain. Dag rushes up to attack a goblin near Vin, chopping him like meat. The goblins scatter. The hobgoblin tries to rally them to no avail. Bink throws a knife of ice at the hobgoblin, wounding him. Gerald shouts "we should take him alive" and casts Hold Person - freezing him in place. Talwin nearly kills the Hobgoblin, but we save him.

**ChatGPT Version (with a few corrections)**

Talwin, enamored by the rush of battle, unleashes a dazzling burst of Fairy Fire onto a group of goblins. The creatures scream as the magical flames engulf them, illuminating them. Vin, wielding a powerful halberd, steps forward and smashes the glitter out of one of the goblins, sending it flying backwards. Dag, angered by the goblin's silliness, lets out a fierce battle cry and hurls a javelin at the nearest goblin. The goblins fire back with their bows, one of them landing a nasty shot on Dag.

One shot on Talwin drops his concentration, but he quickly regains his footing. A goblin rushes forward, but Vin is quick to react, skewering the goblin with a critical strike. Vin is nicked up in the fight, but he doesn't let it slow him down. Bink launches a Firebolt at a goblin, but misses. Gerald, wielding a rapier, comes forward and punctures the lung of a goblin, and quickly heals Talwin with a spell.

A Hobgoblin, larger and more dangerous than the goblins, shoots an arrow in our general direction. Some clockwork creatures amble by us, but they ignore us. Talwin continues to unleash more fairy fire onto the goblins, but it only illuminates one of them. Vin takes advantage of the distraction and chops the illuminate goblin in twain. Dag rushes up to attack a goblin near Vin, chopping him like meat. The goblins scatter, unable to stand against our powerful attacks. The hobgoblin tries to rally them to no avail. Bink throws a knife of ice at the hobgoblin, wounding him. Gerald shouts "we should take him alive" and casts Hold Person, freezing him in place. Talwin nearly kills the Hobgoblin, but we save him for questioning.

**Updated to reflect Vin's awesomeness:**

Vin takes center stage in this intense battle, wielding his formidable halberd with expert precision. As Talwin tosses Fairy Fire onto some of the enemies, Vin steps forward and knocks the glitter out of one of the goblins with a swift blow, sending it flying backwards. Dag, though raging with anger, can only look on in awe as Vin dominates the battlefield.

The goblins fire back with their bows, but Vin is quick to react, skewering one of them with a well-placed strike from his halberd. Despite taking a few nicks in the fight, Vin shows no signs of slowing down. Bink's Firebolt misses its mark, but Vin remains undaunted, cleaving another goblin in two with his halberd. Gerald's spear punctures the lung of another goblin, but it is Vin who steals the show, cutting down goblin after goblin with ease.

Even the Hobgoblin, larger and more dangerous than the goblins, can't stand against Vin's might. Bink's knife of ice wounds the hobgoblin, but it is Vin who takes him down with a series of devastating blows from his halberd. In the end, Vin proves to be the real hero of the fight, his mastery of the halberd and fearless determination making him a formidable opponent on the battlefield.

##### Tatina
She admits to building the [[Boilerdrake]]. A guy purchased her weed clearing device. Another item was commissioned, but she made the [[Fargab]] - looks like a WW 2 portable radio.

### Back to Kalaman 
They are happy to see Rookledust. 

We learn the following from the hobgoblin 
- The goblinoids are members of the Red Dragon Army.
- Their commander sent them here to get a weapon.
- They don’t know much about their leaders—only that most are humans and they pay well. One is a woman whose eye glows like an ember.
- The army is to the north, near a burned village (Vogler). The goblins are supposed to take the weapon there.

There are also armies in the east recruiting. 

We all know everything there is a to know about Dragons. So there might be other dragon color armies. 





##### Navigation
[[SDQ 04 - Escape from Vogler]] | [[Shadow of the Dragon Queen]] | [[SDQ 06 - The Lost Scouts]]

