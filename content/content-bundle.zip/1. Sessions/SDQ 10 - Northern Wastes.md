---
date: 2023-03-03
tags: Session/Dragonlance
---

# SDQ 10 - Northern Wastes
**Date:** 2023-03-03
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
Vin Plates up, using the [[Sir Sarlamir]] armor as a base. Dag carries the [[Dragonlance]] head. Clean up that mess.

[[Marshal Vendri]] and [[Darrett Highwater]] return with the army. She takes charge and set things in order. The next day, Darrett comes to get us. The Dragonarmy has split, and part has going towards the [[Northern Wastes]].

*Marshal Vendri has claimed a modest meeting room down the hall from the council chamber marred by Lord Soth’s attack. The room holds little more than a long table covered in reports, though tall windows offer a stunning view of the city and harbor beyond.*

*The marshal stands by a window, gazing toward the horizon. From a seat at the table, [[Lord Bakaris Uth Estide| Lord Bakaris]] glances at you and then bitterly observes, “Here they are now, Marshal. Perhaps if we hadn’t put our faith in sell­swords, my son would be at my side and the governor would still be alive.”*

Vin and Gerald give disparaging response. Bakaris leaves, we tell our story. The Marshal had our back, and Lord Bakaris tries to hint that we could have done more to save the Council. The Marshal does not make much of it, but Darrett thinks we should investigate.

Darrett, two companies, and our group to find out what [[Lord Soth]] wants there. Research at the castle library reveals: 

* After the Cataclysm, the Northern Wastes became a barren, deadly region prone to flash floods. The grand ruins predating the Cataclysm litter the region, though few explorers survive attempts to seek them
* Marshal Vendri has agreed to send Darrett and the characters to the Northern Wastes to investigate the Dragon Army’s agenda there.
* Darrett will be given command of a few hundred soldiers.
* To avoid drawing the attention of the Dragon Army, Vendri has ordered a few ships to ferry Darrett’s troops across Kalaman Bay at night.
* A secluded cove called [[Wrecker’s Edge]] lies at the southeastern shore of the wastes. This is where the forces will disembark.
* From there, the characters and Darrett’s troops are to discover the Dragon Army’s plot, thwart it, and then return to the ships.

### Wrecker's Edge
*Water sloshes and wood creaks as ships depart from Kalaman’s docks in the dead of night. Citizens gathered to bid farewell to loved ones soon fade from view. The ships cuts through the dark waters of Kalaman Bay, sailing to perilous shores under cloudy skies.*

[[Tatina Rookledust]] and [[Cudgel Ironsmile]] accompany us. Tatina has the [[Fargab]]. 

As we approach Wrecker's Edge. *Waves crash against jagged rocks along the shore. Beyond, red-hued canyons carve their way through a harsh landscape. In the distance, mountainous crags and strange formations jut skyward.*

Its an opportunity to try out the Fargab as Darrett sense us ashore to find a good place to disembark. After an hour, we find a cove with rotted wooden building. There is a longboat (might hold about 12) at anchor, a relative new ship in comparison to the shacks. Vin and Talwin, right above the deck is hazy or shimmer. That is unnatural, perhaps magical. Vin and Gerald recall stories of elves and their ships. Solanesti elves have longboats of this type. If elves, they are really far north. We report in via the Fargab and investigate the shacks.

While abandoned, it has seen recent use. Not orderly. Dag thinks some elves might be nearby. An elf comes into the area. Name [[Dalamar]]. Looking for pre-Cataclysm ruins. They have not encountered the Dragonarmy. He does not their lands were invaded by a separate army, [[Silvanesti]] has fallen (now a haunted land). They were betrayed. We area bit shocked by it. 

![](https://i.imgur.com/GasxAbI.png)

Lord Soth is mentioned by us as well.  Dalamar offers to escort to his camp to see if others have encountered. We contact Darrett to land here, but not bother the ship. Travel overland to the camp. No one trusts elves - they just live too long. 

### Silvanesti Camp
Head north. The feel of Dalamar is one who is focused and sharp, but certainly is focused on his people. There are dozen tents in a spiral pattern on a plateau in an old set of ruins. Intros us. An old elf comes out - [[Zhelsuel]]. There is a tense discussion. 

[[Zhelsuel]] reluctantly decides to answer any questions. Gerlad talks of the [[Sir Sarlamir]] story. Zhelsuel shrugs it off, and the party breaks ups. [[Dalamar]] does react to it and pulls the group aside as they start back to the coast. He has heard of this flying city - the [[City of Lost Names]]. He cannot go with us, but could direct us in exchange for <mark style="background: #ADCCFFA6;">sharing of secrets</mark>.

### Back to the Cove 
Darrett is fully in charge.

![[Darrett Highwater#A Maturing Darrett:]]



##### Navigation
[[SDQ 09 - Sir Caradoc]] | [[Shadow of the Dragon Queen]] | [[SDQ 11- Stormstep]]

