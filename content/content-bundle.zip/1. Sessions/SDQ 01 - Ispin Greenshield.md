---
date: 2022-12-30
tags: Session/Dragonlance
---
# Session 01 - Ispin Greenshield
**Date:** 2022-12-30
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]

## Events
In route to [[Ispin Greenshield]]'s funeral. Vin and Gerald are together, meet Talwin. [[Becklin Uth Viharin]] sent us the invitation.

### Draconians on the Road
Some kid comes out that was in charge of some knight's horses. He rushes out and says guys in robes attacked. We show up, and there is a lizardman with wings!

![](https://i.imgur.com/qXwPqb1.png)

![](https://i.imgur.com/XOXb9JT.png)

[[Draconian]] 

Talwin hoopak's one of the these creatures. A couple run for reinforcements. One comes up and injures Talwin badly. Another rushed up and Vin comes down hard with the halberd, slicing his head open. Vin comes foward and strikes at the Draconian (Kapak, others Baaz). Gerald calls on healing to help out Talwin.

Talwin taunts the Draconian - and it works to well, the Draconian takes him down. This confuses Vin, who misses. Gerald comes forward and stabs him with rapier. Then Vin finished the Draconian with a couple of cheap shots. Revive the Kender as he is a tanky. Other others kinda exploded. This one was very acidic - splashed when died. We take that symbol and tidy up the scene.

Level Up!

### Brass Crab in Volger

![](https://i.imgur.com/QBPkVoD.png)

Off to the Inn of the Brass Crab. Crabby theme. A server from Northern Ergoth. She knew Isban. Kingfisher Festival on as well. We are about to go enjoy the festival, when a female knight of Solomnia walks in. Becklin Uth Viharin, Knight of the Crown. She was a common travelling companion of Isban. She is the Castillion of the local keep.

![](https://i.imgur.com/fZJRDfy.png)

We will go out for a bit and back at dusk for the wake.  We chat a bit about the Draconian encounter. Then around town. 

### The Kingfisher Festival 

There is a bird statue that has been rubbed for good luck - a phoenix, symbol of the old god Habbakuk, of animals of the sea.

![](https://i.imgur.com/VTWgcu2.png)


![](https://i.imgur.com/TXQB1M9.png)

Eventually find ourselves near a noble manner. Hmmm, asshole noble - [[Bakaris Uth Estide]]. Berating a servant.  Vin tries to incite Talwin to hit the noble with a rotten apple. He does it - hits him! We get away with it - a blow for the common people. 

### Funeral 
![](https://i.imgur.com/dQNbnTQ.png)

Send the boat down the river. A fine wake, telling of stories. The asshole shows up. Becklin tells Isban's favorite tell. Tinker gnome, firing of some critter he has to recover. Vin tells of a competition that turns out to be a man, not that there is anything wrong with that. Gerald tells a tale that Asshole downgrades.

[[Cudgel Ironsmile]] leads a mercenary band.
- Loudest voice
- Hitting first usually wins
- Forthright, plays cards. 

There is a blue skinned elf hanging on the edges. Ledara.

Isban leaves us something (for next time).

##### Navigation
 | [[Shadow of the Dragon Queen]] | [[SDQ 02 - Kingfisher Festival]]




