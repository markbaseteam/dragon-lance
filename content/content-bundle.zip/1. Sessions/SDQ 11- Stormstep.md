---
date: 2023-03-10
tags: Session/Dragonlance
---
# SDQ 11 - Stormstep
**Date:** 2023-03-10
**Location:** Northern Wastes
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
-

## Events
A lovely day here in the [[Northern Wastes]]. See evidence of the [[Dragon Army]]. 

### Deepdraught
In the canyon, we can see evidence of past water levels at these site called [[Deepdraught]]. There are blue (see) elves down there, but its low tide. The canyon turns to worked stone, with an entryway with a bird symbol. Meet [[Ishvern Stargazer]].

![](https://i.imgur.com/Ljtdhmb.png)


The bird symbol is a blue phoenix, of the god [[Habbakuk]]. Governs the seas and water, and is a symbol/patron for the [[Knights of Solomnia|Knights of the Crown]]. They are here to go into their temple, but the priest was taken by the Dragon Army. Their scouts come back - they have found their captured comrades - a nearby lake. They hire us to retrieve them in exchange for blue pearls. They are north of another site we are to investigate

### Random Encounter
Low tide. From the crags several [[Spider, Giant|giant spiders]] attack. They about the size of a horse. Dag, who hates spiders, rages, and rushes forward. He wounds one with a wind swing of his greataxe. Talwin tosses Spike Growth to slow several of them. He casts it everywhere, forcing them to come to us. Vin shoots one with a crossbow and readies Blackaxe, his halberd. The grotesque spiders shoot out as bunch of webs over our heads and pull back and up the walls (after taking damage). Dag chops at one as it pulls back. Talwin drops his concentration. Gerald whispers and scares one off, at least for now. Bardic inspiration to Dag.

Dag closes to the wall, and starts to climb after throwing a javelin. Talwin Zephyr Strike (cool move) and kills one. Our forces risk getting split, but at least most of the spiders are on one side. Vin shoots the one on Dag. A spider webs Dag, Restraining him. A spider comes back down to strike at Dag, biting him. Dag shakes off the effects of the poison. The one spider recovers and comes back and tries to restrains Gerald. Another comes forward to bite Talwin. Oh no, he is poisoned and takes extra damage! The last one comes down at Vin. Vin hits him and it stops him. The Spider does toss a web on Vin, restraining him. Gerald comes forward to lunge at the spider on Talwin. Gerald commands Dag to attack. 

Dag breaks out of the web and crushes one of the spiders. He commands Talwin to attack quickly. Talwin kills one of the spiders with his bow. He turns can casts Ice Knife on another one killing another. Vin breaks free of the web and cleaves the one in front of him, killing the creature. He comes over to the one on Dag and smashes it with the butt of his halberd. It tries to flee, but Vin cuts it down.

### Stormstep
![[Stormstep#Stormstep]]

#### Entry Level
Dag steps in. 

*This round chamber is illuminated by white flames flickering in magical sconces on the walls. In the room’s center stands a gleaming obsidian statue of a solemn elf warrior. Around the statue’s pedestal, hundreds of silver coins lie scattered in the dust. Beyond, a staircase ascends, curving along the tower’s north wall.*

Talwin cannot resists and comes forward, touching the statue. This is guardian over [[Silvanesti]] burial sites. Its best leave a coin. We ascend the stairs after leaving a coin. 

#### Second Level
*Heaps of rubble have fallen from this chamber’s partially collapsed ceiling. The room holds two stone crypts, while the walls are sculpted with empty burial niches. A door stands to the southeast. Sconces on the walls shed light tinged a faint green.*

As we enter, spirits rise up! 

##### Wraith Battle
Two [[Wraith|Wraiths]] rise up. Talwin tosses Fairy Fire on one of them, but it saves. Gerald runs one through, damage it. Dag gains inspiration. The wraiths float forward. One gets close to Vin and he strikes it, but it nearly drains Talwin to a husk. He fails the save, and thus is has very low hit points until rests. The other strikes at Gerald but misses. Dag is enraged and strikes at the wraith, ripping chunks of its essence away. He follows up with the magical long sword, which is very effective against the creature. Vin tears into the same wraith, hitting three time, but its still up. 

Talwin Zephyr's out of harms way and shoots an arrow at it. Gerald tosses an empowered Whisper, and it forces it away. Gerald pulls back. Then commands Dag to attack the wraith with the magic sword but misses. One wraith misses Dag. The other wraith recovers and races back in but Vin stops it cold (Sentinel). Dag tears into his, destroying it. Vin continues to wear on the other one. 

Talwin tosses Ice Knife at the last one, heavily damaging it. Gerald Whispers, injuring it but not enough to get it to flee. Commands Dag to attack, hitting it. The spirit, enraged, misses. Dag destroys it. Victory!

Vin attunes to a Cloak of Protection. 


##### Navigation
[[SDQ 10 - Northern Wastes]] | [[Shadow of the Dragon Queen]] | [[SDQ 12 - Tower of Wakenreth]]

