---
date: 2023-05-26
tags: Session/Dragonlance
---
# SDQ 18 - TBD
**Date:** 2023-05-26
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
Rest and find the wine as noted in the prior session. 

#### To the Northwest 
*The tunnel fills with the sound of rattling as the bones in the walls begin to move, some lashing toward you. Chattering jaws hiss ancient words as incomplete skeletons burst forth.*
*In Draconic: You fly on our backs, you soar on our bones*

[[Dragon Skeletons]] attack! Vin strikes the nearest, doing moderate damage. One strikes Dag rather hard, but leaves an opening for Vin to strike. One misses Gerald, who then lashes out with his rapier. Talwin Ice Strikes one of the skeletons. Vin wears on one. Bink drops a wall of fire on two of them, killing one. The two serpentine skeletons miss. Eventually Dag kills the one Vin has been working on. Vin finishes the last one. 

The passage wraps around to the south to the flooded room.

#### Flooded Room 
*Murals of dancing people cover the walls, and a small stone stage rises to the west. The lower southwest half of the room is flooded, with the remains of tables, chairs, and a bar barely protruding above the water’s surface.*

There is a [[Green Slaad]]  shaman!

##### Slaad Fight 
Talwin is not able to hit the casting shaman in time as a fireball envelopes the heroes. Only Vin, due to his lucky charm, makes the save. Gerald whispers and damaged the foul creature. Dag rushes forward, tossing javelins. Vin comes up and trips the creature with is Dancing Longsword. Bink Shatters him, doing moderate damage. 

Talwin tosses out heals. The Slaad regenerates, and it tosses fire onto the water, which has a layer of oil. Gerald whispers and heals. Dag steps up out of the water and hits with his great axe. Vin steps up out of the water as well. Vin puts a bit hit (crit) on the creature, impressing it with his fighting prowess. Bink mops it up! 

#### The Den 
*Crumbled chairs lie toppled about the room. On the north wall hangs a long stone slab that features a bas-relief depicting dragons bowing respectfully over a large dragon corpse. A dragon skull is mounted on the east wall.*

The skull says in Draconic:
*“You built your degenerate throne on our graves and used our ancestors to fuel your ambition. But your gods abandoned you, and we struck you down. You return … and so do we.”*

Then the following materialize through the skull 
![](https://i.imgur.com/18cMRO8.png)

Dag rages and attack. Vin more calmly comes up and double crits and flexes on this creature. Gerald Whispers. Bink Firebolt, just enough to take it below half. Talwin heals. The Death Dragon breaths purple flame onto Gerald, Bink, and Dag. Vin Inspires Bink, allowing him to at least live through the attack. 

Dag hits on the creature and tries to order Vin to attack. Vin raises an eyebrow at this. He then tears into the creature, hitting three times. Gerald Whispers, striking with psychic damage. This forced the creature to pull back, drawing hits from Dag and Vin. Bink tosses Thunder Orb, destroying it!

[[Lessor Death Dragon]]

A short rest, then move on.

#### Laboratory 
*This worked stone room is full of laboratory equipment: vials of colorful liquids, glass lenses, and live mice in cages. Books crowd shelves and overflow into the floor.*

Books look pre-Cataclysm old. Gerald learns the following

**City of Lost Names**
History of the City

The tragic history of the City of Lost Names began long before the Cataclysm. The characters might learn parts of this history during their exploration.

Departure of Dragons

During a conflict called the Third Dragon War, many generations before the Cataclysm, the hero Huma Dragonbane defeated Takhisis and prevented her conquest of Krynn. When the Dragon Queen left the world, her wicked dragon servants went with her. To maintain the balance between good and evil, most of Krynn’s metallic dragons agreed among themselves to retreat to hidden reaches of the world.

Built on Bones

Centuries passed. In that time, the last kingpriest rose to power in the land of Istar. This religious leader dreamed of an earthly paradise—a pleasure city to reward those he deemed righteous. The kingpriest and his servants created a great flying island. He named this aerial city Onyari, the City Without Sin, claiming it would be a place where he and his worthiest (and wealthiest) subjects might cast off mortal weakness and live like the gods.

But the kingpriest and his servants were loath to reveal how they created their paradise. The city was constructed on an ancient sacred site where, for millennia, dragons of Krynn had gone to die. The kingpriest harnessed the magical resonance of the dragons buried there, lifting the city into the sky.

Fall of Onyari

When the metallic dragons remaining on Krynn learned the kingpriest had desecrated the resting place of their dead, they were furious. Though some dragons urged a more moderate path, the gold dragon Karavarix refused to hold back. He led a contingent of metallic dragons to the soaring city, intent on forcing it to land. The god Paladine tasked the Knight of Solamnia Zanas Sarlamir (see chapter 4) with peaceably ending the conflict between the dragons and the kingpriest. However, Sarlamir’s quest was a dismal failure, ultimately resulting in the knight attacking and killing Karavarix. The resulting battle between the dragons and Onyari’s people ended in Sarlamir’s death and the city’s ruin. The flying city fell apart across the Northern Wastes, its bulk ultimately crashing in the hidden depression where it lies now.

Not willing to acknowledge his failure, the kingpriest suppressed all records of Onyari, and those who knew of the failed marvel refused to speak its name. In the wake of the Cataclysm, those few who remember Onyari at all know it only as the City of Lost Names.

##### The Mice
Bink talks to the mice - scary person come in. Lots of light and sound, and sometimes she kills the mice. 


Other Loot: Scrolls

##### Navigation
[[SDQ 17 - Path of Memories]] | [[Shadow of the Dragon Queen]] | [[SDQ 19 - Temple of Paladine]]

