---
date: 2023-01-13
tags: Session/Dragonlance
---
# SDQ 03 -Vogler Burns

**Date:** 2023-01-13
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
-  [[Dag Greywolf]] - [[Bryan]]

## Events
Mayo [[Raven Uth Volger]]  is going to send out patrols to find out if there are more mercenaries on the bad side of the law. At noon, the scouts return with dire news. There is an army nearby.  "Sounds like a local problem." Humans and hooded figures.

[[Becklin Uth Viharin]] talks with us about hooden figures - draconians. 

Raven wants to send a representative to declare neutrality. Then [[Jeyev Veldrews]], a loyal merc, comes in.

*On her return, Cudgel found Jeyev and other loyal mercenaries had heard of the events at High Hill. They had restrained several soldiers loyal to Gragonis but who didn’t have orders to participate in the reenactment.

*During the night, Jeyev’s scouts came across a large military force to the northwest of the village, much too large and organized to be a mere mercenary band. This is the same army the characters likely spotted, and Jeyev’s scouts can confirm everything from the “Sighting the Enemy” section.

Then [[Bakaris Uth Estide]] comes in and says something useless.

*Beneath the carvings of leaping fish etched into Vogler’s open wooden gate, a human in black-and-red scale mail sits astride an armored warhorse. She holds out a rolled parchment and calls out, “Who among you speaks for this village?”*

#### The Letter
*People of Vogler,

*By the orders of [[Belephaion]], the Voice of [[Takhisis]], you will quarter the soldiers of the invincible Red Dragon Army this night. Refuse and die.*

*This is the Dragon Queen’s will.*

### The Decision
They are inclined to hold them off. A Gnome wants to fling us so we can take out the scouts. 

Gnome Flinger
![](https://i.imgur.com/MubRDE7.png)

NaryCrash
![](https://i.imgur.com/1s1W5nD.png)

- Talwin goes first --- flies through the air with the greatest of ease
- Gerald  - good
- Vin - good
- Dag - good 
Thank you for flying Mt Nevermind Airways. 

### The Escarpment
Post Fling, we look to clear the area. Four dragon soldiers, they draw swords that have just of a flicker of flame. They have scalemail and a shield. We are disoriented from the flight.

The sodiers are closing. Gerald comes forward, and does bardic inspiration on Talwin. Talwin shoots one with a longbow, annoying him. Vin comes across to protect Gerald and shoots a crossbow. He gets ready to defend with his halberd. Dag comes up and tosses a javelin.

One comes forward to attack Dag, Vin misses with is Polearm. Hits Dag. Others come forward, must have a deflective pole arm. One hits Vin. Gerald steps and finishes the injured one. Talwin shoots another. Vin hits one, taking him to the ground and moves for better position. Dag is going to rage and tear into them. We are wearing them down.

Vin finishes one of the warriors. Dag does heavy damage to the last one, but he fights on. Gerald mops the last one. 

Some of us take the flaming longswords. Scalemail is good to take as well (has dragon queen emblem)

### Back to Vogler 
Inform them of events. Prepare for war! Becklin and the Mayor think it best to evacuate.

*Colorful Kingfisher Festival decorations still cover the village circle and the festival stage. Unlike the day before, the people collected in the village center are somber, muttering in worried tones as Mayor Raven takes the stage.*

*Following the mayor’s report, the locals stand in stunned silence. Then their questions come in a wave of shouting, anger, and fear.*

Gerald helps Raven calm the crowd.

*Cudgel has directed the Ironclad Regiment to hold a position north of the village. The mercenaries believe they can, for a time, defend against a larger force.

*She hopes they won’t have to fight. With any luck, a show of force will convince the Dragon Army that Vogler isn’t an easy target.

*Just in case, her soldiers set up a small rear command tent near the River Gate. She’s posted a messenger there so the village can send word to her troops as needed.

*She asks Becklin to join her at the front. She hopes if a Knight of Solamnia appears on the field, the enemy will hesitate to provoke the knighthood.

Becklin agrees to do it, but is not pleased to do it. She knows it will be her death. She gives a thoughtful look to her squire [[Darrett Highwater]]. She comes over to us for a favor. In the keep, a box for Darrett once he escapes. It has a Kingfisher on the lid. She thanks us, and then goes to plan more of the battle.

Time to withdrawal. 



### Rearguard duty.
*The villagers remain eerily quiet as they begin lowering themselves into the boats. Panic washes over the crowd as cloaked figures emerge at the edge of the cliff above Vogler. The figures linger for a moment, then step off the edge. Wings sweep from beneath their cloaks, slowing their descent into the village.*

We go into the town to hold them off

*The sound of clashing metal draws your attention. Two of Vogler’s remaining militia members struggle to hold their own against reptile-headed invaders. The scaled soldiers bait the militia members, hissing cruel laughter.*

Stoner [[Draconian|draconians]]. Vin takes one out quickly. Dag steps up to toss a javelin, hurting one badly. Guard takes badly and the draconians turn to us. One comes up and Vin strikes him, but he misses. One puts a minor hit on Dag.  Talwin throws an Iceknife at one and hits (Inspiration), wounding them. 

Vin smashes one in the face with the butt of his halberd to little effect. Dag kills the one in front of him. The remainder rush, Vin gets a quick slash on one of them. Talwin misses. Gerald thrusts with his rapier, plunging deep in into the foul creature.

Vin finishes the one on Gerald, leaving two. Dag destroys the one in front of him.  The draconian strikes at Vin  and misses, and Vin Repostes to kill him.



##### Navigation
 [[SDQ 02 - Kingfisher Festival]]| [[Shadow of the Dragon Queen]] | [[SDQ 04 - Escape from Vogler]]

