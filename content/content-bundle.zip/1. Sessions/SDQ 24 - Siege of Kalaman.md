---
date: 2023-07-21
tags: Session/Dragonlance
---
# SDQ 24
**Date:** 2023-07-21
**Location:** [[Kalaman]] 
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]


## Events
We rest, but are awoken by horns the next day. 

*The siege of Kalaman has begun. Thousands of Dragon Army troops—humans, draconians, and other creatures—march on the city. Along the walls, Kalaman soldiers shout commands while ballistae fire in rapid percussion, their deadly bolts barely keeping the dragonnels wheeling overhead at bay. Beyond the dragonnel riders, the flying citadel looms like a thunderhead, drifting slowly but relentlessly closer.*

### Sivaks on the Wall
Dag and Vin look at each other and both say "ballistae". Sivak [[Draconian]]s drop out of the sky towards it.  Talwin misses with his Ice Knife, and resists his taunt. Vin uses the wall to position himself to stop the first draconian, inflicting heavy damage and preventing a Sivak from attacking. A second Savik attacks Vin to no avail. A third misses Dag. The last attacks Gerald and takes several hits. Gerald does get a quick opening against one of them flying by but misses. Dag screams in rage and tears into one of them. Gerald Whispers, inflicting psychic damage.

Tawlin fails to Ice Knight again, and fails to tight. Vin kills one, who tries to form a scary Vin. "You cannot scare me with me!" Shouts Vin. The draconians circle. Vin and Dag get nicked up., Vin fends one off from Gerald. Dag pounds one into the wall, which creates Scary Dag. This does unsettle Gerald. Gerald does Counter Charm to ward off these frightening effects and gives Barding Inspiration to Vin. 

Talwin strikes one of the two remaining. Vin starts to work on the one in front of him. It turns into a real fight. Dag tears into another. Gerald Whispers and gives Commanding Rally to Vin, who does hit! (but it was on a 20 and rolled off). He uses inspiration to do more damage. Talwin mops the one in front of Vin, making a scary Talwin. Talwin drops hunters mark on the last one and kill it too! But even two Scary Talwins are not scary. 

### Dragonnel Riders!
Ballistae time! That does get three [[Dragonnel]] riders coming our way. Vin hits one Dragonnel with a ballistae bolt, but it does not take it down. Dag tosses a couple of javelins at the same creature, heavily injuring. Talwin finishes it, dropping its rider to his death. Gerald drops a fireball, injuring the remaining 2 dragonnel and riders. The riders fire heavy crossbows at Dag and Gerald. Gerald is hit. 

Talwin tosses a few arrows to no effect. Vin pulls out Dragonlance to try to fend off the team that has targeted Gerald, ripping a long gash in its chest and plowing open its scales. That throws it off course. This messes up their attacks, although one shoots Gerald. Gerald drops a whisper on the dragonnel on Vin, chasing him away.  Vin cuts the dragonnel out from under a rider, thing strikes the ride twice before he falls. 

Talwin shoots his bow at the fleeing Dragonnel, getting good damage on him.  Vin shouts "Come back and die for your cause, boy!" It does! But goes after Talwin. Dag, waiting for him, leaps into action. He kills the dragonnel. 

### Our Rides Arrive
A message comes, our Dragonnels are on the other side of the city. Lord [[Darrett Highwater]] also wants us to find [[Tatina Rookledust]] as well. Ooo, they have a Gnomeflinger! 



##### Navigation
[[SDQ 23 - Death of Barkaris]] | [[Shadow of the Dragon Queen]] | [[SDQ 25 - Storming the Citadel]]

