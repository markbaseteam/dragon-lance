---
date: 2023-04-28
tags: Session/Dragonlance
---
# SDQ 16 - City of Lost Names
**Date:** 2023-04-28
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]

## Events
In the middle of the fight. Lonnie is out, do Bink runs away in terror but Dag has returned. Vin tosses a blanket and gets a better idea of where this Draco-Slaad is. He hits once. Tawlin drops a Fairie Fire into the area, but it has magic resistance. Gerald then drops Dispel Magic, wiping out the Invisibility! Vin misses on a Commanding Rally. Draco-Slaad hurls flame at Vin and Gerald. Gerald is looking a bit burnt. The creature has healed up some (regeneration).

Dag rushes forward angrily, hitting once, and commands Talwin to attack, but misses. Vin hits the creature once. Talwin misses with the hookpak but does mark it (Hunters Mark). Gerald casts the Whispers, effecting it. Dag does big damage on the creature with the Commanding Rally. The creature tries it bite out of Vin, but misses. It does it with a claw on Dag and Vin, but Vin gets a big hit in with Sentinal. 

Dag finishes it! It does not regenerate after death.

Loot! Gems, a Wand of Smooth Wood (Wand of the War Mage - +1 to magic attacks). Find notes.

Talwin touches it again, but resists.

### Notes
*Virruza was following orders from a Dragon Army commander named [[Belephaion]].
*His mission was to investigate the monster-­creating stone unearthed here.
*He was optimistic he could use the stone’s magic to create a disease to turn people into draconians.
*[[Virruza]] notes that exposure to what he calls the “Spawning Shard” has begun to change him.
*After this, the notes grow sloppy and nonsensical.

![](https://i.imgur.com/ckQajtW.png)


Here is what it does mechanically:
A creature that touches the gem must succeed on a DC 15 Constitution saving throw or become infected with a disease called chaos phage. While infected, the target can’t regain hit points, and its hit point maximum is reduced by 10 (3d6) every 24 hours unless the target is cured by magic such as the lesser restoration spell. If the disease reduces the target’s hit point maximum to 0, the target instantly transforms into a red slaad or, if it has the ability to cast spells of 3rd level or higher, a green slaad. Only a wish spell can reverse the transformation.

We will return [[Yearkal]] the priestess to the [[Blue Phoenix Shrine]]. Talks about [[Habbakuk]] with Gerald since that is symbol of the Knights of the Crown.

### On the Way to the Shrine.
Message from [[Dalamar]]  - return to him ([[Stormstep]]). We ignore and go toward [[Deepdraught]].

### Deepdraught  
Get another call from Dalamar :). At the [[Blue Phoenix Shrine]].  They will enter the Shrine of [[Habbakuk]] on the morning. 

*An ancient, algae-covered double door made of white granite stands here. It is etched with an eroded image of a majestic bird with outstretched wings.*

Yearkal opens the door by simply callout out the gods named .

*A long room stretches ahead, its walls carved with motifs of rolling waves. A ceiling supported by twin pillars glows with faint blue light. At the rear of the chamber stands an altar carved with coral-like designs. Behind it rises a sizable granite sculpture depicting the bird from the shrine’s entrance, its outstretched wings wreathed in flames. An archway opens into a chamber to the west, while a simple stone door stands in the wall to the east.*

She leads us to a side room and says to cleanse ourselves.

*In the center of this room rests a three-foot-high brass basin filled with clear water. A relief ornaments the walls, depicting great sea birds dipping into the waves alongside leaping fish and whimsical creatures.*

To another room around back. 

*Alcoves to the west and east of this chamber hold waist-high stone sarcophagi sculpted with images of shells and graceful sea creatures.*

The design on the lid looks to be a design of the chapel. The other has a name "Erizel, a devote Priest". She makes an offering and a secret door opens. 

*Steps ascend into a room covered in thick, black algae. At the center of the room stands a well, from which emanates the sound of distant waves and the cries of sea birds.*

We gain a Blessing - [[Habbakuk]] Bless - Advantage with a Survival checks. 

Quest complete!

### To Dalamar 
The tower partially in the Faewild - we have returned.

He chastises us for taking too long. [[Dalamar]] is dismissive of the return of the gods. But he has sussed out here the City of Lost Names is - its about 50 miles ot the NW at the Giant's Spine (K).

### To the City of Lost Names  
After a travel; montage, 

*A vast plateau rises from the wastes, its ancient cliffs soaring hundreds of feet high. A broad canyon splits the plateau’s face, its passage blocked by an aged stone wall. Countless red tents spills from the canyon and its gate. Innumerable Dragon Army troops swarm the land, while patrols of dragonnels soar above.*

![](https://i.imgur.com/JQbMLbl.png)

They outnumber our Company. Decide to ambush a foot patrol to see if we can get more info.

Well, our ambush is not all the good. But the battle starts. Dag rushes up and tosses javelins. They rush forward and toss as well, hitting Dag a number of times. One hits Talwin as well. Vin rushes up, saving Dag and chopping up one pretty good, but he is still alive. Gerald Mocks the injured one, and mops him ("you call that dragon armor, this is dragon armor"). This inspires Vin. Talwin Markes a target, and hits one with his bow. 

Dag, in his element, tears into one of the [[Dragon Army Soldier]]s, killing him.  The soldiers advance but Vin stops one in his tracks. Vin finishes the one in front of him, steps ahead, and hits and trips the one in front of Gerald intimidates him and gets him to give up, although he is rather contemptuously. Talwin moves his mark to one of the two on Dag and hits. Dag is still unsure if he is allowed to kill the ones in front of him. The two soldiers are not unsure and strike Dag. Vin comes up and he is still unsure if we should kill them or not, and cuts of retreat. Gerald he calls for the other two to surrender. They laugh at the thought. Talwin's shot goes astray.

Dag toys with them, hitting one, leaving an opening for Vin to slip in a shot (Command). The two Dragon Soldiers soldier on, attacking Dag. A few strikes hits. Vin finishes him off.

##### Interrogation
- *The canyon leads to the City of Lost Names.
- *There, the army’s leaders—the mage [[Lohezet]] and the priest [[Belephaion]]—seek an ancient weapon.
- *They are accompanied by the terrifying knight [[Lord Soth]] and hundreds of other troops.
- *The canyon to the city is blocked by a simple stone fortification—a remnant of a long-vanished people.
- *The walls surrounding the ruined city are riddled with passages. One leads from the city to Wind’s End, a landing point for Dragon Army dragonnels.

Vin somehow knows abit about Lord Soth. Cursed by the gods and an undead knight. Plate Armor and a mace/brand as a weapon (purple fire). Commands an army of undead. Soth and his contingent are technically not part of the [[Dragon Army]].


### Darret Shows Up
[[Darrett Highwater]] shows up. He might be able to create a distraction for us to get in at Wind's End to face Lord Soth. Might be a suicide mission all around. 


End of Session - Level up to 8th!




##### Navigation
[[SDQ 16 - City of Lost Names]] | [[Shadow of the Dragon Queen]] | [[SDQ 17 - Path of Memories]]

