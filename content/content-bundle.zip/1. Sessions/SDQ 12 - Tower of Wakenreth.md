---
date: 2023-03-17
tags: Session/Dragonlance
---
# SDQ 12 -
**Date:** 2023-03-17
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
### On to the third floor.

*The room’s shattered walls stand frozen in time, hovering a heartbeat away from falling apart.*

*A sizable hole gapes in the room’s floor. To the south, rubble blocks a staircase leading down, while to the north, another staircase climbs to the level above. Dismal gray-green light shines from flickering wall sconces, eerily illuminating yellowed bones fallen from burial niches and scattered across the floor.*

There is a ghostly female elf there trying to grab a new sword. Gerald advances to help. The sword appears elvish. The Towers down not - it seems Astari. She notices Gerald finally, and speaks in an ancient dialect. She is Jentida, a Guardian of [[Silvanesti]]. She says there is something wrong about this place, and indicates something above that angers her. Its her sword. It has some power.  She asks of her sister Tenadria. There are (were) a delegation from Silvanesti to the Istar. The city she mentions was a flying city of Onyari.

Vin takes the sword since its magical - it would be a good backup.

#### Fourth Floor 
*The door opens into a room that hovers in a starless night sky. Though the floor is stable, shattered wall fragments float in the air, their sconces emitting a faint, sickly green light. Beyond the broken walls lies an endless black expanse.*

*Across the platform stands a stone archway sculpted with sharp runes and the heads of five dragons. Within the arch swirls dense gray mist.*

Dragon heads are of the green dragon shape. There are ruins on the statue. Its like a Dragonlance Stargate. There is something moving on the other side of this "portal". Elvish in look. A spirit of some sort, and gives a greeting in an ancient elvish dialect. His name is Veriel. 

This is the [[Tower of Wakenreth]]. He is a guardian. The tower was a symbol of cooperation between the elves and Istarians. During the cataclysm struck and he tried to shift to the Feywild, but is now partially in the Shadowfell. He wants use to align the runes and it would sever the link. But that might take down the tower. Also, Vin is not sure that spirit is what he says he is.

After debate, we will do it. The rest of us exit. Bink casts Fly and is going to do the sequence. The portal is building up energy and Bing is suspicious. Switch the Fly to Vin to hang out at the same level but outside the tower. Continue on - power builds then something appears ([[Anhkolox]])

![](https://i.imgur.com/ynXlEeY.png)

Dag and Gerald rush up the tower. The demon rushes forward but Bink throws up a Shield, and it barely misses. Vin flies in and strikes the creature twice. Bink pulls back and hits it with a ball of lightning. 

The creature eyes Vin and smashes him, then engulfs him. Vin is down for the count! It then the smashes Bink into a paste. Vin recovers enough to rip into it from the inside. Dag comes up and is disturbed by the scene and misses, but grants Vin another attack. The creature is roaring in pain and anger. Gerald heals Bink to get him up. Vin continues to rip at it from the inside, and nearly levers the creature in such a way to trip it, but it keeps its balance. Bink, now up, Orbs it with a critical!

For whatever reason, Gerald finishes aligning the runes. He is somewhat drained by this, but it does work! Its free of the Shadowfell!  The tower is in prestine conditon! 

### Dragon Army Camp 
*Ahead, the smells of rotting fish and burning flesh hang thick in the air. A fortified camp sits atop cliffs jutting from the center of a muddy lake. The camp is ringed by immense bone spurs, with makeshift wooden walls between. A wooden palisade surrounds a camp composed of tents, huts, and a crooked watchtower. Dozens of Dragon Army soldiers keep watch around the camp.*

*The bare wooden beams of the camp’s central watchtower support a makeshift platform with just enough room for four soldiers to stand comfortably.*

*A wooden bridge crosses the marshy lake, which reeks with decay. The bridge ends at the camp’s gate.*

*A large, hastily made wooden gate blocks access to the camp. The area is guarded by three imposing figures with twisted draconic features.*

Bink does perceive there is something in the camp in a cage or stable. Could be a [[Dragonnel]] or something similar. Bink will do some scouting. Bink gets inside the walls and finds a set of cages. He cannot quite see what is in them. Bink tosses a rock and a blue skined elf comes to the front of the cage.

After snooping around, Bink almost gets away when a Sivak Draconian spots Bink. He rumbles in Draconic "We have a vistor"

[[Camp Carrionclay]]
[[Draconian]]

Shawn on PTO next two session, pick up April 7th.

##### Navigation
[[SDQ 11- Stormstep]] | [[Shadow of the Dragon Queen]] | TBD

