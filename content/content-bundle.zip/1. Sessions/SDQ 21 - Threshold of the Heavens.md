---
date: 2023-06-16
tags: Session/Dragonlance
---
# SDQ 21 -Threshold of the Heavens 
**Date:** 2023-06-16
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- Out

## Events


### Threshold of the Heavens
The passphrase to gain entrance to the Threshold of the Heavens is “By her will: the world.”

Around it are Sivak [[Draconian]]s. There are several captains on [[Dragonnel]] around. Talwin shape changes into a hawk to fly up to let down rope. Manage to climb and remain undetected up on the Threshold of the Heavens.

*Atop the floating island, a slender, gray obelisk rises nearly two hundred feet above the surrounding plaza. Four graceful flying buttresses curve up the tower’s entire height, and crystalline windows punctuate its summit. At the tower’s base stands a single stone door. Four hulking draconians guard the door, while armored dragonnels and their riders circle above.*

Since we have no plan, we boldly approach as if we belong. We will attempt to use the passphrase and go in. And it works! Weird. 

*Murals of idyllic life in the flying city adorn this grand foyer’s gray stone walls. One on the west wall depicts a handsome, long-haired man in flowing robes, radiating golden light. Fountains burble to the north and south. The east wall holds a single door to the north and a double door to the south.*

Also in there are a couple of Bozaks and a [[Bone Devil]]. Gerald bluffs him as well (from Hask, to see Belephaion). We guess the double doors are the way. 

*Two long consoles jut from the walls of this room, covered in levers, colored stones, and dull glass hemispheres. Etched into the floor between the consoles is an elaborate symbol radiating orange light.*
![](https://i.imgur.com/veYeKjg.png)

Talwin pushes a few buttons and tower drops about 10'. We hastely open the other door and go up the stairs. 
#### Second Floor 
*Nine blue crystalline columns crackle and hiss as lightning arcs unpredictably between them. A double door leads to another room to the north, and a smaller door leads to the stairs down.*

The group manages to avoid the energy to another set of door. 

*Stone columns inset with glowing crystal bands run along the north side of this room. Between the columns stand two still, insect-like constructs. Sporadically, lightning arcs between a column and one of the constructs. To the southeast, an array of runes pulses on a console. In the middle of the south wall stands a small door and, to the west of it, a larger double door.*

[[Istarian Drone]]

The constructs begin to attack us. One spews forth a sparkling gel at Talwin and Vin, who both throw themselves against the wall to avoid it. The other comes forward and grabs both Talwin and Dag. Vin is about to strike it as nears. Dag rages and starts beating on the Drone (while grappled, he can still attack). Talwin strikes with with Ice Knife. From around the corner comes [[Flameskull]]s!  Three fireballs hit the group! Gerald strikes at a drone and does a bit of healing on himself.  Vin destroys the first Drone and strikes the second, providing an opening to move forward. 

The Drone attacks poorly, missing. Dag continues forward to attack a Flameskull - heavy damage. Dag creates an opening for Vin to finish off one of the Flameskulls. Talwin drops a healing on Dag and himself. The skulls pull back a bit and take advantage of the high ceiling. The launch fire rays and Dag and Vin. Dag is taking pretty heavy damage.  One was going to critical Vin, but Luckily he ducks behind the pillar. Gerald Whispers, impacting one of the skulls. Dag gets a commanding rally on the drone. Vin continues to tear into the drone, but its still going strong. 

The Drone spews again, but again it misses ("dont stand in the stupid"). Dag jumps up on the console to swing at one of the skulls, but slips and is not able to get up there. He resorts to throwing javelins, hitting a Skull. Talwin heals Dag for a bit and hoopaks a skull. The skulls fire more rays, targeting Dag and wearing on him. Gerald  does a mass heal. Vin arms himself with the Dragonlance to be able to attack the flying skull. He destroys one and heavily damages the other. 

Drone attacks ambles forward and attacks Talwin and Gerald. Gerald's dragon armor does give a bit of protection from the lightning and it has them grappled. Dag goes back to crush the machine and gives commanding rally to Gerald. He  crits, but crap damage. Talwin hoopaks the drone, annoying it. The skull takes it fustration out on Vin, who again uses a pillar to avoid some of the damage (Luck) but still takes one shot in the face. Gerald precise strikes the drone. Dag strikes on commanding rally, hitting the drone for pretty heavy damage. Vin finish off both the Skull and the Drone.

Short rest, then third floor.

#### Third Floor 
*In the middle of this room stands a three-foot-tall, circular metal pedestal. Atop it, hundreds of tiny illusory buildings glow in a pale yellow light, and in their center floats a miniature illusion of the Threshold of the Heavens. Four crystal globes mounted on the walls glow with the same light, projecting illusory images onto the pedestal. Doors lead to the north and west, and a third door leads to the stairs down.*

Talwin touches everything, nothing. 

An adjacent room has the following.
*Three chairs are scattered across this room. Blackened consoles against the west and south walls buzz softly and occasionally emit sparks. Doors lead to the north and east.*

Room to the north: 
There are Aurak Draconians (gold), Dag gets a free round of attacks but whiffs. Gathering himself he then strikes the Draconian twice, heavily. Gerald  strikes with his rapier, further injuring one of them. He does commanding rally on Dag, hitting pretty hard. Vin finishes him, but is stunned by the electricity when it explodes. The remaining draconian spews a cone of something foul, burring them. Talwin hoopaks the draconian. Dag rushes forward to attack the last one, critting it. Gerald wears the creature down. Vin is bardically inspired. Vin finishes the Draconian off. 

*A large table fills the center of this room, and beyond it, the north wall holds a door. Atop the table, a three-dimensional illusion depicts a vast, rocky expanse in meticulous detail.*
Vin and Gerald recognize this is a live view of the area. We see the battle moving away from the area. The Calaman army has been mauled but is feisty.

Next Session - July 6th. Game likely ends around Gencon.


##### Navigation
 [[SDQ 20 - The Manor]]| [[Shadow of the Dragon Queen]] | [[SDQ 22 - Belephaian]]

