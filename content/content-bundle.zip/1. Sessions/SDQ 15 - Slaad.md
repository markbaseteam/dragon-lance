---
date: 2023-04-21
tags: Session/Dragonlance
---
# SDQ 15 - Slaad
**Date:** 2023-04-21
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
To [[Sunward Fortress]] to rescue. [[Clystran]] is our guide. Over 40 miles.  

### Sunward Fortress 
*Amid the natural stone formations of the Northern Wastes, a broken, hundred-foot spire lies half buried. The massive spire’s base and toppled pinnacle would be easy to miss were it not for the excavation sites and abandoned tents surrounding them.

A monster or other entity looks to have wiped out this [[Dragon Army Soldier]]. This site looks to have been religion based.

*A ramp of packed clay descends from the surface through a gap in the ancient stone wall. It emerges into a chamber thick with dust and old air. Atop a low dais to the north stands an altar carved with candle sconces, a shallow basin, and stylized flames. To the south, a spiral stairwell winds downward. To the east, an archway leads to another chamber.*

Temple is/was dedicated to [[Sirrion]], god of fire and change. 

#### Lower Level
*The stairs descend into an space surrounded by a series of halls and cramped rooms. A thick, rotten smell permeates the air. Digging equipment and crates have been crammed into every corner and alcove.*

There is something ahead, clawed feet on stone. Bloated [[Draconian]] - a [[Dracophage]]. Two rush in, attacking Talwin and Gerald. A bit of a tussle. Talwin is able to disengage from the melee and it explodes when hit by a stone from his Hoopak. A spray of acid erupts, but Gerald side steps.  More emerge. Vin tears into a few, Gerlad mops up several. Bink drops Shatter. Down to one, but he rips into Gerald, who goes down. Vin retaliates and trips him. Bink steps forward and zaps him, blowing him up. Bink gets Gerald back on his feet. 

We take a short rest for Gerald to recover a bit. 

Walking around, Vin finds an alcove that has stuff piled out. After a bit we fine the Sea Elf cleric. [[Yearkal]]  and a human named [[Rone]]. 

*When Yearkal was captured and brought here, the Dragon Army made her join the workers unearthing this ruin. The camp’s commander had orders to recover whatever relics or magic lie within.

*They eventually dug up a large, glowing stone. Soon after, violent, toad-like terrors emerged.

*Yearkal and Rone fled but were recaptured by Virruza, a magic-using draconian.

**[[Virruza]] seeks to use the magic of the stone to transform people into draconians. However, his actions caused more monsters to emerge.

*Since then, Yearkal and Rone have been hiding here. Rone has felt unusual for the last few days, but he’s grown increasingly ill in the last day.

*Yearkal knows there are other sea elves at the [[Blue Phoenix Shrine]] and [[Camp Carrionclay]]. She wishes to reunite with all of them.

We provide some healing (Restoration) to Rone. Rone is from [[Hearts Hallow]]. 

#### Subcavern
*This level of the fortress hasn’t been fully excavated. A thirty-foot-wide chasm splits it in two, spanned by makeshift wooden footbridges. On the far side of the chasm, digging implements surround an eight-foot-tall crystal glowing with a noxious orange light. On the near side of the chasm, a hulking red form covered in squirming shapes digs through broken crates.*
![](https://i.imgur.com/tPHBekp.png)

Bink drops a Fireball, killing some of the tabpoles and moderately injuring the [[Slaad]]. Gerald steps forward, attacks! Vin kncoks it down and tears into it. Now, it gets up and heals some if its damage. It attacks Vin and Gerald, but it leaves an opening for Vin to nearly slice out its spleen, if it has one. Talwin casts Hunter's Mark but misses the attack. The Tadpoles leap out and attack, but misses. Bink drops a chromatic orb, killing the larger Slaad. Vin and Gerald finish off the tadpoles. 

Going to investigate the big glowing crystal, a large green Sload attacks! That seems to be this [[Virruza]] that we heard about! Bink tosses Chill Touch,  hit it and stopping regeneration. Vin comes forward to secure the bridge, and strikes with the dancing sword. Talwin dashed forward but misses with the Hoopak. Gerald advances and still casts detect magic on the crystal, detecting Alteration and Transmutation. It hocks up a fireball. Its somewhat impactful on our crew. 

Bink casts Haste on Vin! Vin comes up and hits it like 7 times! That does take it to Blooded - that is a ton of hit points! Talwin re-applies Hunters Mark and strikes the creature with a stone. Gerald steps up to attack, striking true and healing himself. The foul creature Virruza regenerates and turns invisible!

Bink tosses a fireball to take down a bridge to trap the creature. Vin adjusts position and readies to strike. Talwin casts Gust to put out the fire on the new bridge. We know its in the corner. Now its a game of cat and mouse. Vin tosses some of his crossbow bolts on the ground to help detect it if it comes his way. Talwin, of course, goes and touches the stone. He starts to transform be resists. 

We pick up next time with the Sload Sub Hunt!

##### Navigation
 [[SDQ 14 - Double Dragon Day]]| [[Shadow of the Dragon Queen]] | [[SDQ 15 - Slaad]]

