---
date: 2023-01-20
tags: Session/Dragonlance
---
# SDQ 04 - Escape from Vogler
**Date:** 2023-01-20
**Location:** Vogler
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Dag Greywolf]] - [[Bryan]]
- Visit by [[Lonnie]]

## Events
The battle in the city of Volger continues. A new type of [[Draconian]] swoops down towards Gerald. Vin yells out, somehow lowering his initiative. Dag tosses a Javelin at it, nearly skewering it. Gerald pokes at it with is rapier, and Vin misses as it closes. The Kapak Draconian slashes Gerald. It has a nasty poison. Vin attempts to avenge Gerald's death. The creature looks menacing at us, hovering over Gerald's body.

Dag rages, but misses. Gerald does not make the first death save. The creature splits its attacks. It hits Dag and misses Vin, who immediately reposte, killing it. The draconian bursts into acid, further injuring Dag and Gerald. Fortunately, there is a potion of healing.

The town is not doing well. The haze thins for a moment, and Vin sees: 
*A distant flash of light catches your attention. Atop the cliffs north of town, three figures on motionless horses sit in the shadows of the trees. You make out the glint of light on plate armor, but before you can alert your companions, the figures vanish.*

Vin senses a historic moment has just passed him by (History - 1).

### The Dragon 
Approaching the wharves - 
*The screams of villagers, still evacuating onto boats, ring through the smoke of burning buildings. Among the screams rises an unbelievable word: “Dragon!”*

*Then it comes into view. Pitching this way and that, its scales clanking like steel plates, a black beast draws near the wharf, flanked by reptilian invaders. Flames crackle from the beast’s gaping maw.*

But we do NOT perceive that its a contraption mocked up as a dragon. Thus, it will go down in the annuals as a real one.

A Baaz Draconian gently caresses the dragon. Very odd. Gerald does Vicious Mockery in Draconic. Some of the draconians are slowed by injuries. Vin comes up and fires of his crossbow at a draconian - but it strikes the dragon, bouncing off his scales. Dag comes up. Another draconian come up and does another caress to the dragon and it turns. The other gooses the dragon and it spews fire, destroying the building next to us. Another draconian drops something on Dag, and its some sort of firepot.

Another draconian shouts out "Your Turned too Far You Idiots!" Massaging. We can see that this dragon is more mechancial than living. Some gnomish contraption! Gerald stabs a draconian, running it through, but now has to extract his weapon. Vin rushes up but misses. Dag rages and misses as well.  Draconians counter, wearing on us. Hmmm, Gerald is turning to stone, but is still mocking others. Gerald breaks out of the stone sheen that was covering him. Vin tears into the draconian in front of him, hurting it badly. Dag destroys one. Vin finishes him, and we avoid the stone effect.

The dragon is know as a [[Boilerdrake]].

### Ogre
*An exterior wall of the Brass Crab shatters outward. A ten-foot-tall brute in black scale armor emerges from the inn. Holding a barrel of fish under one arm, the hulking figure fills her mouth with a fistful of wriggling fish.*

*From behind her, two reptilian soldiers emerge. “Them next,” the ogre says, gesturing in your direction. The soldiers move forward obediently.*

Unfortunately, we do not have time to figure out the mechanical dragon. The ogre, [[Fewmaster Gholcag]], comes forward and tosses a javelin at Gerald, hurting him. Vin fires off his crossbow (misses) and gets into defensive position. Dag rushes up and hits, cutting into the foul beast. 

Gerald comes forward and strikes at the Ogre, further injuring him. Vin finishes the large lady, and the other Draconians withdraw in awe.

### Escape
*“Hold the boat!” a voice rasps from the smoke-shrouded street. A man runs through the haze toward the wharf, clad in the armor of an Ironclad Regiment mercenary and gripping a horned helmet in his hand.*

*Vogler is in flames. Amid the columns of smoke rising from the village, invaders loot what remains. The villagers traveling with you don’t look away, watching until their home is nothing more than a red-black smear along the river’s edge. The evacuation boats carry all that remains of Vogler down the Vingaard, toward an uncertain sanctuary in Kalaman.*

![](https://i.imgur.com/PlOSxnp.png)

Last boat to [[Kalaman]]

#### Level Up
Dag and Gerald becomes Knights of the Crown. Vin takes Sentinel. 

"Don't expect me to go around "sir-ing" you two" ~ Vin 

### On the River
Dag knows a bit of Kalaman. 

Characters who are from Kalaman or succeed on a DC 12 Intelligence (History) check know the following details about the city:
- Capital City. Kalaman is the capital of the Solamnic province of Nightlund.
- Ancient Bastion. Kalaman is a thriving trade city known for its strong walls, castle, and harbor beacons, all of which predate the Cataclysm.
- Rulers. The city is led by a governor, a council of prominent guild leaders, and a military marshal.
- Military. Kalaman maintains a significant military force to deter raiders from Estwilde and monsters from the Dargaard Mountains.
- Vingaard Port. The city sits at the mouth of the Vingaard River, about thirty miles downriver from Vogler.

[[Darrett Highwater]], [[Raven Uth Volger]], [[Jeyev Veldrews]]. Seems like the rest of the [[Ironclad Regiment]] is gone. Gives [[Becklin Uth Viharin]]'s helm to Darrett.

Everyone else is all "best a knight, courage, etc". Vin is like "run to fight another day, like we are doing now."

### Arrive in Kalaman 
*The walled city of Kalaman rises in the distance, spreading across the southern shore of a wide bay. Ships sail to and from the city’s walled harbor, their courses lit by a pair of towering beacons.*

*On the shore ahead, where the Vingaard River meets Kalaman Bay, dozens of survivors from Vogler have pulled their mismatched boats ashore and ­begun making camp.*

Vin lights up his cigar, surveying the scene. 

##### Navigation
 [[SDQ 03 - Vogler Burns]] | [[Shadow of the Dragon Queen]] | [[SDQ 05 - Rookledust]]

