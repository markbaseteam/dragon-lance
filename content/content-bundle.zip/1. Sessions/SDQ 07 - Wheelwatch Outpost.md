---
date: 2023-02-10
tags: Session/Dragonlance
---
# SDQ 07 - Wheelwatch Outpost
**Date:** 2023-02-10
**Location:** Wheelwatch Outpost
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
[[Darrett Highwater]] - new mission - lost an outpost to the dragon army. Its to the SE. [[Raven Uth Volger]] wants to go, with some soldiers.  Go to a secluded grove about a mile from the keep. Four corner keep, one with a larger tower. Big horns. [[Wheelwatch Outpost]]. 135' square, stone walls.

The Battle for Wheelwatch Outpost was a dangerous mission. The outpost had been lost to the dragon army and Raven Uth Volger, along with some soldiers and the heroes, were tasked with reclaiming it. The outpost was located in a secluded grove about a mile away from the keep, a 135' square stone fortress with four corners and one large tower.

The Vogler militia, along with Raven, scouted the area for the rest of the day. The overcast weather, quarter white moon, and red moon three-quarters full were taken into consideration for a potential night assault.

Using the spell Pass Without Trace, Talwin helped the group stealthily approach the northwest tower where the guards were inattentive. Vin and Dag quickly scaled the wall and secured a rope for the rest of the group.

In the courtyard, there were several small structures and stairs leading to the fort's battlements. The plan was for Bink to use his Fog Cloud spell to cover their approach and then use his skills with tools to open the gate, while the rest provided overwatch.

However, the spell went off and Talwin was distracted by something on the ground, causing Dag to rush forward in frustration and attack the dragon soldiers. The group fought off the soldiers, with Bink successfully opening the gate. The militia then ran in to join the fight.

The group encountered Ardlic Vanse, a fearsome opponent, but managed to defeat him with the help of the militia. The battle was intense, with losses on both sides and a Dragon Warrior on a Dragonnel escaping.

In the end, the group discovered two people in the cells, Elgo Duckditcher and Lanal Brint. The Battle for Wheelwatch Outpost was a hard-fought victory for the Vogler militia and a step towards reclaiming their lost outpost.


![](https://i.imgur.com/EskQCVp.png)

### Back to Kalaman. 

After their previous mission, the heroes returned to [[Kalaman]] only to find the main castle strangely quiet. They soon learned that a contingent of Dragon Army troops had broken away from the main force and Kalaman's leadership, spurred on by [[Bakaris Uth Estide]] , had decided to take aggressive action against them. With [[Marshal Vendri]] away leading troops further west,  [[Governor Calof Miat]] approved the strike, with Lord Bakaris and his son leading the attack and Darrett serving under them. They plan to ambush the Red Dragon Army near a crossing of the Inkwater called Steel Springs, thirty miles west of Kalaman.

However, a mysterious note arrived urging the heroes to come quickly, warning that Bakaris was leading them to ruin at [[Steel Springs]], thirty miles west of Kalaman. The heroes soon realized that this was the same mission that Bakaris and his group were undertaking, and the [[Darrett Highwater]]  could not disobey their orders. The heroes knew they had to act fast to prevent a disastrous outcome, and set out towards Steel Springs to try and intervene.

##### Navigation
 [[SDQ 06 - The Lost Scouts]]| [[Shadow of the Dragon Queen]] | [[SDQ 08 - Steel Springs]]

