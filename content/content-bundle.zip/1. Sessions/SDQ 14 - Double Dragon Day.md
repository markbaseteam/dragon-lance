---
date: 2023-04-14
tags: Session/Dragonlance
---
# SDQ 14 - Double Dragon Day!
**Date:** 2023-04-14
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
We explore [[Camp Carrionclay]].

*Four dilapidated iron prison pens hold prisoners of the Dragon Army. Bloodstains spatter the ground beneath and around the cages.*

There are a couple of Sea Elves, a female [[Kennah Lightfoot]] the Kender, and a [[Bulette]] crashing against its cage.

*The bare wooden beams of the camp’s central watchtower support a makeshift platform with just enough room for four soldiers to stand comfortably.*

The priest was taken to [[Sunward Fortress]], top the east. The Kender is from [[Hearts Hallow]], two days NW of here.

*This hut is larger than the others in the camp. It’s made of hides stretched over a wooden frame, with bone spikes protruding from the ground around it.*

There are field reports. Looking for an item or relic.  Letter from a commander named [[Belephaion]] - he was the commander of the Dragon Army that attacked [[Vogler]]. They are looking to excavate [[Sunward Fortress]]. There is a large secure chest, and in it is a very large egg (dragon egg). Gerald is 100% sure its a dragon egg (nat 20), Vin is 100% sure its a not (probably a bulette egg - nat 1). 

As we decide to leave, fricking [[Dragon, Black]] lands! "That is one scare flying bulette"! Try a strategic withdraw. It laughs at us, blasts Talwin, who is standing admiring it, and is blasts him with acid. Although he dodges, it is badly burned. Then if flies off.

Level Up!

### Hearts Hallow
*Water rushes into the canyon ahead, rising swiftly. The sudden flooding has spurred creatures to seek higher ground—including a human in rugged leathers rapidly climbing a rope out of the chasm, pursued by several horse-sized spiders.*

[[Clystran]] is the one dangling from a rope. Kennah know him. Rush forward to help. Gerald spooks one of the spiders. Bink drops Fireball! Takes out 3 of the remaining 4. The frightened spider works it ways back, and the second tries to bite the man. Vin cleaves into the near spider, killing it. The Dancing sword jumps out of the scabbard and slays the other. To [[Hearts Hallow]] 

Go have a drink in a bard that is suspended over the pit. Taking about why we are here. There is a woman with an intense gaze on us. City of Lost Names. The woman, middle aged but commanding presence, confronts Gerald. Her name is [[Nesra]], she is the mayor.

There is significant discussion about the egg. Eventually, she reveals herself as a Bronze Dragon! Ok, we will leave it here. So two Dragons in one day. Gerald takes the [[Dragon Scale Mail]].

We can use this as a safe haven so long as we do not reveal its location. 

Show her the Lance head, she nots the magic is inert. 

Talk a bit about [[Takhisis]] and her possible return, and what the black dragon portends. She is concerned about the [[Draconian]]. She recommends Clystran as a guide. 






##### Navigation
[[SDQ 13 - Battle of Camp Carrionclay]] | [[Shadow of the Dragon Queen]] | [[SDQ 15 - Slaad]]

