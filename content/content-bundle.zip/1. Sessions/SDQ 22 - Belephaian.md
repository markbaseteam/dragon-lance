---
date: 2023-07-07
tags: Session/Dragonlance
---
# SDQ 22 -Belephaian
**Date:** 2023-07-07
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- 

## Events
*Window-like crystal panels dominate the walls of this room, each displaying a different image. Three show crackling thunderheads, and the fourth depicts the city of Kalaman. In the center of the room, stone desks with magical consoles surround a raised platform. Doors lead to the north and south.*

![](https://i.imgur.com/85FPlvq.png)

![](https://i.imgur.com/t3hGJYl.png)

This guy is a contractor. [[Belephaion]] is upstairs, you kill him we are cool.

*Enormous windows fill the walls of this room, granting a breathtaking view of the City of Lost Names. Lowered walkways line three walls like orchestra pits, while a dais in the center holds a bejeweled throne whose back is carved like the rays of the sun. Seated on the throne is a human man dressed in crimson robes and wearing a crown bearing the Dragon Queen’s symbol. Also a pair of Bozak [[Draconian]]s *

*“It seems Lohezet has finally been dealt with.” The man on the throne brings his hand down on a crimson jewel on the throne’s arm. “No more need for his incessant human cautiousness. Glory will be mine alone. It is the Dragon Queen’s will!”*

*The jewels on the throne pulse. Beneath you, the floor lurches. Through the windows, the city’s towers shudder, and the ruins begin to rise into the air.*

We attack!

Tawlin casts Zephir Strike and shoots him, striking with a critical. Vin readys to attack. [[Belephaion]] transforms into a dragon!
![](https://i.imgur.com/i9C7tBr.png)

He breaths lightning at Vin, for minimal effect. Vin charges in with the Dragonlance and hits hard, unsettling the dragon. But the weapon is a bit unweildy, making it hard for Vin to strike again. Gerald casts fireball! This wears on the dragon. The Bozaks toss lightining bolts as us. [[Dragon, Blue]]

Note: Once again, [[Bryan]] does not fight a dragon.

Talwin Hunters Mark the Dragon and does some damage.  Vin, getting the Dragonlance under control, slays the Dragon. A Bozak tries to web us, but fail. The other drops Stinking Cloud, effecting Talwin. He is now a retching kender, which is redundant. Vin moves out of the cloud, killing one of the Bozaks, taking a bit of damage as it explodes. Gerald moves out and takes on the last Bozak. The Bozak counters but misses.

Talwin recovers from the cloud and strikes from range, critically striking it. It blows up, only minor damage to Gerald. 

*The shaking underfoot continues. Outside the windows, boulder-sized chunks of the city tear free, rising into the air. Beneath them, whole districts shudder as mighty forces tug them skyward.*
This thing is going to crash! Since we are not attuned to it, we have no chance to take control. We flee, and the black robed wizard is gone.

We get out. 

*You find yourself amid disaster as ragged stone islands and crumbling buildings rise into the sky. Chaos confounds the Dragon Army troops throughout the city. Dragonnels dodge stones in the skies, while winged draconians race to escape cracking streets.*

*To the south, violet flame lights the sky. At its center, a solid island rises, its stone foundations riddled with monstrous bones. The island bears an ominous temple, windows alight with otherworldly violet flame. As you watch, the undead dragon ridden by Lord Soth returns, and the two circle this blazing flying citadel.*

*You find yourself amid disaster as ragged stone islands and crumbling buildings rise into the sky. Chaos confounds the Dragon Army troops throughout the city. Dragonnels dodge stones in the skies, while winged draconians race to escape cracking streets.

*To the south, violet flame lights the sky. At its center, a solid island rises, its stone foundations riddled with monstrous bones. The island bears an ominous temple, windows alight with otherworldly violet flame. As you watch, the undead dragon ridden by Lord Soth returns, and the two circle this blazing flying citadel.

*Kalaman’s surviving soldiers made camp on a bluff east of the City of Lost Names—or what remains of it. In the distance, a constellation of rocks floats in the air, some the size of islands, others little more than boulders. However, the largest island advances south from the ruins, positioning itself above the reassembling Dragon Army forces. The island holds aloft a sinister temple with otherworldly violet light gleaming from its cracked walls. Its exposed foundations crawl with creatures of blackened bone and violet flame. As you watch, several of these skeletal dragons spread tattered wings, lurching into the sky to circle the citadel like gigantic vultures.*

[[Darrett Highwater]] tasks us to try to warn [[Kalaman]]. On the road again!

### Kalaman 
We arrive ahead of the flying citadel. Go to [[Marshal Vendri]]. 

*This familiar conference hall and its large round table have seen significant repairs since last you were here. Marshal Vendri and [[Lord Bakaris Uth Estide|Lord Bakaris]] sit at the table, along with various bickering strangers who wear the colors of Kalaman guilds. Opposite the door, a woman in simple clothes sits in the governor’s chair, watching the proceedings with uncertainty.

*Marshal Vendri sees you and stands, surprise clear on her face.

Soth is on his way with a flying fortress. We reveal the Dragonlance. 

##### Navigation
[[SDQ 21 - Threshold of the Heavens]] | [[Shadow of the Dragon Queen]] | [[SDQ 23 - Death of Barkaris]]

