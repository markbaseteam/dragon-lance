---
date: 2023-05-19
tags: Session/Dragonlance
---
# SDQ 17 - Secret Passage
**Date:** 2023-05-19
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
[[Darrett Highwater]] and his Company attack! We take advantage of the din of battle to make our way to the [[City of Lost Names]]. 

*Ahead lies the outpost called Wind’s End, a ramshackle enclosure pressed against massive cliff walls. Beside it, a strip of land has been cleared of rocks.*

*Right on cue, shouts ring out to the southwest, quickly followed by smoke and alarm bells. In the distance, the silvery armor of Kalaman’s soldiers cuts a swath through the unprepared Dragon Army camp.*

*As chaos unfolds, most of the Dragon Army soldiers stationed at Wind’s End rush their dragonnel mounts into the air, leaving the outpost vulnerable.*

Trusting that the din of battle will protect us, the heroes advances, preparing to fight as the one [[Dragon Army Soldier]] calls out about intruders. Bink does injure the soldier with a firebolt. There is a roar from the stables as Dag advances, who misses with two javelins. Gerald comes forward, whispering nasty things at the soldier. Vin sweeps that legs from under the soldier and follows up quickly with two strikes. Talwin was not ready for the swiftness of the strike. The soldier gets up spitting mad, but swings wide. Another soldier comes out and attacks Gerald, slighting cutting him. Bink hits the first solider (officer) with a Chromatic Orb. Then a rider of a [[Dragonnel]] comes around the corner. Dag rushes the first officer and misses. Gerald whispers to the one beside him, forcing him to run away. He does a quick strike as the officier backs off. 

Vin finishes the officier, and steps up to provide control against several soldiers that came of the fray. Talwin pulls back behind Vin and tries to hit the [[Dragonnel]] with fairie fire, but it shakes it off. Several come forward and tear into Vin and Bink. The [[Dragonnel]] tries to fly over and rake Talwin, but misses. Bing tosses Haste on Dag. Dag rages and tries to swing at the lumbering beast as it takes to the air, but only hitting once. One of the officers guts Bink, nearly taking him down. Gerald ties to turn the Dragonnel into a butterfly, but it shakes off the magic. He commands Dag to strike the beast and he hits. 

Vin strikes at the head of the Officier on Bink, allowing him to withdraw. Vin strikes again, slowing the enemy. Fireball and a big hit from Dag takes out the Dragonel. The officer riding him lands painfully, and Dag strikes at him as well, finishing him! 

Vin tears into the other officer, tripping him and doing heavy damage. Talwin mops. Bink finishes the last officer. We are in the clear as the battle drifts away. 

In the stables, we find a hidden passage. 

### Passage to City of Lost Names 
*The passage from Wind’s End runs through ancient stone, winding through darkness alive with skittering insects. After traveling for hundreds of feet, you pass a large seam in the wall, after which the rock’s texture abruptly changes. Ahead, the tunnels stretch on.*

As we continue, we hear whispers that start to agitate us.

*As you approach a fork in the tunnel, the walls burst into green flame that rushes toward you. Spectral dragon heads erupt from the flames, and the corridor fills with furious, hissed words.*

Talwin cannot control his thoughts and hits Gerald with his hoopak, hitting him. Dag swings at Bink, pulling his swing at the last second. We shakes this off, and any menace appears gone. A short rest allows us to catch our breath. Continue on. 

*Mismatched bones lie scattered around this large chamber. Though the cavern itself is natural, its ceiling has caved in—and with it, part of a building has fallen into the cavern. Inside the collapsed structure are strewn wooden heads and decaying hats.*

Is this an old haberdashery? There is a statue under the hats. As they got there, the statues begins to move. The casters know that this is a Stone Golem and warn of its invulnerabilities. Vin steps up and strikes with the Magic Dancing Sword, and is able to getting Gerald out of harms way. Its a critical hit! Dag uses the magic longsword, inflicting more damage. The golem tries to Slow the warriors, but fails. But it does slow Talwin. Slowly, the group wears down the stone monstrosity. 

#### To the South
Beyond the Golem 
*This chamber transitions from natural stone to walls and a floor of worked marble blocks. The passage tilts down to the southwest, where a carving depicts a dragon in flight. Half the dragon’s body is submerged in dark water, and the hallway beyond it is completely flooded.*

#### To the North 
*A structure from above has collapsed into this cavern. Smashed barrels, shelving, and shards of colored glass clutter the chamber. A staircase that once led up to the east is blocked by rubble.*

We look to rest up. Bink summons an invisible dog to look over us. When we finally get up, Talwin rushes into the North room and finds one crate of wine. Its from the times of the [[Cataclysm]]. Dag swills a bottle down. The rest of us realize its valuable and save ours.  

##### Navigation
 [[SDQ 16 - City of Lost Names]]| [[Shadow of the Dragon Queen]] | [[SDQ 18 - More Memories]]

