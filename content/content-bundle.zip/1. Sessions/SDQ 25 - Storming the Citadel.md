---
date: 2023-08-11
tags: Session/Dragonlance
---
# Session 25 - Storming the Citadel  
**Date:** 2023-08-04
  
## PCs  
- [[Gerald Waylan]] - Daymude, Mark  
- [[Dag Greywolf]] - Bryan  
- [[Talwin Lightfood]] - Paul  
  
## Events  
Fly on the Dragonnels towards citadel.  A red dragonnel, ridden by the Red Ruin, and another appears.  Dag recognizes the other as the Younger [[Bakaris Uth Estide|Bakaris]].  The Red Ruin shoots a hand crossbow at Dag.  It blossoms into a fireball.  He then stabs the dragonnel with the Dragonlance.  The Red Ruin dips suddenly and is stabbed instead.  
  
Talwin hits her with Ice Knife and the Gerald changes her dragonnel into a jackass.  She falls but hits him with a fireball breaking his concentration.  
  
Dag attacks the dragonnel again hurting it.  Talwin hits it as well. Bakaris tries to rescue to the Red Ruin, but cannot pull her up.  Gerald whispers to the dragonnel, killing it.  The Red Ruin hits the ground, but think maybe not killed.  
  
Dag and Talwin kill Bakaris' dragonnel and he falls from the sky. He disappears in the chaos.  
  
*The flying citadel rises upon an inverted mountain of black stone and exposed dragon bones. Fissures riddle this foundation, creating tunnels that extend deep into the rock. Clystran guides his dragonnel close to one of these, a natural shelf with space enough to land. Beyond, a narrow cave cuts its way into the depths of the flying citadel.*  
  
Take a short rest so Gerald can rest.  Talwin guesses have about three hours before the citadel reaches Kalaman.  
  
*The tunnels leading into the foundations of the flying citadel are completely dark. Occasional rumbles echo through the passages as the citadel's foundation shifts in flight.*  
  
*The tunnels that wind through the foundation of the flying citadel rise via a natural shaft into this rocky cavity. A gash in the rock forms a passage to the east, where a familiar, blue-skinned elf in a pale dress stands with a knowing smile on her face.*  
  
Leedara tells us the following:  
  
- *Lord Soth lurks in the ruins above. He's using the Cataclysmic fire from Kalaman's catacombs to control the flying citadel and reanimate dragon skeletons buried in the flying island's foundations.*  
- *If the characters can quell the Cataclysmic fire, the Undead dragons will be destroyed and the flying citadel will fall.*  
- *Leedara isn't certain how to quell the Cataclysmic fire. The flames were created by the gods, so it stands that the power of the gods could extinguish them.*  
- *Lord Soth is a peerless foe. The characters won't be able to stand against him in battle.*  
- *Hidden somewhere in the chambers ahead is an elven relic known as the mirror of reflected pasts. Those who view the mirror see glimpses of their past.*  
- *Leedara believes the mirror can distract Soth, giving the characters a chance to extinguish the Cataclysmic fire.*  
  
Leedara reveals her ghostly form.  Was with Isolde, Soth's wife.  She was one of the elf maids that distracted him from preventing from the Cataclysm.  She is cursed to be a ghost, but is also a curse on Soth.   
  
*Spaced evenly about the perimeter of this chamber are numerous bricked-over stone archways. Plaques are set into many of these arches. At the room's center stands a raised stone dais bearing an ominous statue. A double door, a smaller door, and a stairwell stand at the east end of the room.*  
  
Dag and Talwin go to inspect the statue.  
  
*In the center of the crypt, a dais bears a statue of a robed figure with a grim skull for a face. Before the statue, a pair of skeletons kneel, holding an altar of polished black stone between them.*  
  
Dag is creeped out and doesn't want to go up.  
  
Talwin hears a voice, *"I find you worthy. Join me, and I will open the River of  
Souls to you."* He declines, saying "Pass."  
  
We are in the Temple of Takhisis.  
  
Gerald casts Detect Magic, strong necromantic aura on the aura.  Tendrils of magic go to the statue, but the altar is the primary source.  
  
Dag checks out the large, stone double-doors that lead from the room.  Three figures in bas-relief, two elf men and and elven woman.  One is more in the forefront.  Very stately looking in fine robes, in a very formal pose.  
  
Another nondescript door out of the room as well.  
  
Head up the stairs.  Dag opens a door and two skeletal warriors are there.  Gerald steps in and does minimal damage.  He commands Dag to attack and he delivers a harder hit.   
  
Talwin tries an Ice Knife and taunts.   
  
Coridoor to the north and two doorways.  One plain door and double-door with a bas-relief of Takhisis.  Dag goes through the double-doors.  
  
*Crumbled frescoes lie along the walls of this dilapidated sanctuary. A twenty-foot-tall statue of the Dragon Queen dominates the west end of the room, with smaller statues arrayed behind it.*  
  
Statues are of the evil gods.  6 Bozak and 1 Aurak draconians in the room as well.  Dag throws a javelin but misses.  He is caught in a web, then hit by lightning by some of the others.   
  
Talwin and Gerald enter the room. Talwin and Dag focus on the Aurak, while Gerald drops a couple of fireballs on the Bozaks. The fight with the Aurak goes back and forth, but it is killed.  
  
The group examines the statue of Takhisis.  There is the phrase “Yield to her will” carved in front of it. There are also indications on the floor around it that could be used as hand holds.
##### Navigation
[[SDQ 24 - Siege of Kalaman]] | [[Shadow of the Dragon Queen]] | [[SDQ 26 - Finale - Crash of the Citadel]]

