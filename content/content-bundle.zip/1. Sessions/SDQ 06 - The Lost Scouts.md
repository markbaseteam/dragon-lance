---
date: 2023-02-03
tags: Session/Dragonlance
---
# SDQ 06 -The Lost Scouts
**Date:** 2023-02-03
**Location:** Kalaman, Birch Copse near Vogler
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
The adventuring party has returned to [[Kalaman]] after a successful journey and are taking advantage of the week of downtime before embarking on their next quest. Gerald visits [[Jeyev Veldrews]], but finds out he has already moved on. During this week, the party hears rumors about the old gods and trained dragons serving in an army. To pass the time, each member of the party pursues their own interests. Vin spends his time in the tavern, gathering rumors and telling tales, while Gerald is also in the tavern either correcting the story or adding to it. Dag works on improving his survival techniques, and Bink collects herbs.

![[Vin against the Dragonlord's Goblins]]

Just when they thought they could relax, [[Darrett Highwater]] shows up with a new mission. The scouts sent to [[Vogler]] have gone missing, and the party is tasked with finding them near an area with birch trees, which is uncommon in the region. Darrett provides them with supplies and transport across the river and instructs them to signal for the return of the transport after 20 minutes. The adventuring party is ready for another journey filled with adventure and excitement.

### Lost Scouts
About a days march to the northwest, lead by Vin on a game trail, we near the target zone. Dag and Gerald spot the gray tops of the birch trees. 

Approaching the woods, Bink and Vin hear the raspy voices of [[Draconian|Draconians]]. Bink tries to sneak up and falls into a sinkhole! (critfail). Clearly the draconians hear it. Its Baaz. There is time to set up for the oncoming creatures. There is also a Kapak Draconian this is running, using its vestigial wings to speed it along. They close, unsure about us. Dag comes forward and draws them out. We form a line. There are four Baaz and one Kapak flapping around somewhere. 

Bink climbs a tree, unfortunately that is where the Kapak is advancing toward. Dag, angry at the world, hurls a javelin at one, wounding it. Draconian close on him, but are cowed by his rage and are rather ineffective. Sigh, Gerald runs in there as well and Commanding Rally (Dag gets a free reroll). Gerald then stabs one. Vin comes up and kills that some one. 

The Kapak sneaks up on the Bink and whispers in Draconic "must be my lucky day" and slashes Bink with a poisoned dagger. Bink is hardy enough to stave off its effects and triggers his magical Shield spell to ward of the second attack. Bink hits the Kapak with a crackling Chromatic Orb (Lightning).

Dag continues to wail on the same draconian, finally killing him. He says something dumb in Solamnic and Vin just gives him a wry smile (passes on the attack from Commanding Rally). Gerald and Dag are starting to turn to stone, but Dag does break free. Gerald calls on Healing Word to help Bink. Vin, still with a wry smile on his face, maneuvers behind the draconians, heroically setting up attacks.

The Kapak's attack rakes down the magical shield, missing Bink. Bink casts web, but does not entangle the Kapak. Jumping out of the tree, the Kapak futilely swings at Bing as he floats down to the ground (Featherfall).

Dag chops one of the remaining Baaz with his greataxe, but it continues to fight. The Baaz slash at Dag but miss. Gerald is now more mobile, steps up and hits the other Baaz. He calls on Dag to "Finish him", and be barely does. Vin tears into the remaining Baaz, but its still up. The Kapak glides to another tree. Bink reachs with a Chill Touch at the Baaz. It fights on.

Dag misses, but rallies Gerald to finish off the Baaz, which of course nearly petrifies Gerald.  

Victory!

Bink - "No more overwatch. That did not work out right."

The ballad composed by [[Vin Messere]] 
![[Save the Scouts - Battle Against the Draconians]]

Cut down the scout. The other scout is dead. Harbard is alive, Tobin is dead. We learn
- Dragon Army has split forces to attack communities across Hinterlund and Nightlund 
- They are intent on isolation Kalaman from the Solamnic cities of Maelgoth and Palanthas in the west
- The leader of the army is named [[Dragon Highmaster Kansaldi Fire-Eyes]]

### Soldiers in the Dell 
We return with the body and Halbard to a place to camp. Rest overnight then start out to signal for the boat. But before then, on [[Vogler]] side, we see a camp of humanoids. Alignment is unclear. Bing sneaks up to find out more. They are bedraggled soldiers. There is a dwarf and tall blonde woman. Its the [[Ironclad Regiment]]! Or what's left of it. About another dozen or so mixed forces, and not all of the Regiment.

The group announces itself and come into the dell. It is [[Cudgel Ironsmile]] and [[Becklin Uth Viharin]]. Becklin was freed, so [[Jeyev Veldrews]] did not lie. We catch up, they are headed to Kalaman. While ragtag, its still more arms. Becklin asks about Darrett and is relieved. 

### To Kalaman 
A fine reunion between Becklin  and Darrett. Cudgel meets with the Marshal and gets the same deal.

Our reward - 100 gp.
5th Level!


















##### Navigation
[[SDQ 05 - Rookledust]] | [[Shadow of the Dragon Queen]] | [[SDQ 07 - Wheelwatch Outpost]]

