---
date: 2023-01-06
tags: Session/Dragonlance
---
# SDQ 02
**Date:** 2023-01-06
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Dag Greywolf]] - [[Bryan]]

## Events
Dag Woodwolf finally show up. On the way up to the castle, meet [[Darrett Highwater]], a squire of [[Becklin Uth Viharin]]. Vin eggs Dag into a mild fist fight. All in good fun. More Kingfisher festival. We get fish pies.

### Thornwall Keep
A three story tower, the tallest building in the town. There is a very weird catapult. Have a meal before business.Talk with [[Becklin Uth Viharin]]. 

*Becklin reenters the room carrying a shallow wooden box, approximately three feet to a side. She sets it down gently on a table. “Ispin left this for all of you,” she explains. “But it comes with a condition. Since he won’t be attending the Kingfisher Festival this year, he wanted you all to participate for him. Specifically, he hoped you’d take his place during the reenactment of the Battle of High Hill. Every year, he looked forward to participating—and dying—in an even more ludicrous way than the year before.”*

There is a +1 green shield. [[Ispin's Green Shield]] - to Gerald.

### The Festival
*Colorful banners and paper decorations shaped like kingfishers decorate the village circle. Temporary stalls sell food and colorful crafts, and in the center of the circle, an ancient tree provides shade for happy picnickers. From a temporary stage, a band of local musicians brings a spirited song to a close as Mayor Raven Uth Vogler takes the stage.*

Mayor - [[Raven Uth Volger]]
*“Welcome, friends!” the mayor begins, raising her arms high. “Welcome to the Kingfisher Festival!”*

*Cheers and applause fill the circle. The mayor smiles widely. “Today is a day of not only revelry but also reflection. We are all here thanks to the courage of heroes who came before us. Let us honor our founders, our family, and all those who can’t be here to celebrate today. Enjoy your festival, Vogler, with good spirits, good times, and good friends! And look to the kingfishers for good luck!”*

*An energetic round of cheers follows the mayor’s words. With that, the Kingfisher Festival is officially underway.*

![](https://i.imgur.com/pIzWGS7.png)

### Fish Catching Competition
*A fishing pole resting on her shoulder, Raven takes her place as one of the competitors and beckons other participants to line up with her along the docks. "It's time to find out who among us kingfisher fisherfolk is the fisher king!" the mayor says as she casts her line into the Vingaard River. The competitors receive her pun with good-spirited groans and laughter, then cast their lines as well.*

R1 Vin - Critical Fish!
R2 Vin - Fishin man
R3 Vin - Solid
4' of Fish

Bet is Dag has to clean Vin's boots. Vin, of course, cheats (bait and switch). Came in third behind the mayor and some other local.

[[Bakaris Uth Estide]], is being an ass, again. Dag tries to punch him, Bakaris sways out of the way. But he does pull the punch. 

### Battle Reenactment
Head to the hill. Becklin joins us. Gerald drones on about history.

*Passing through woods and fields, Vogler’s parade of militia members and reenactment spectators finally reaches High Hill. The grassy slope is spotted with trees and crumbled stone fencing. Near the base, several dozen soldiers in matching armor stand in even formation. The contrast is striking between these mercenaries of the Ironclad Regiment and Vogler’s militia—with their mismatched armor and crooked helmets—but it does nothing to dampen the spirits of those assembled for the Kingfisher Festival’s climactic reenactment.*

[[Ironclad Regiment]]

*After much laughter and jostling, the mayor, Cudgel, and other spectators walk to a nearby vantage to watch. As they do, the militia takes up its position atop High Hill—the same hill Solamnic troops held centuries ago. They face the mercenaries of the Ironclad Regiment at the base of the hill, arrayed as the forces of Istar once were. Although the event is only a reenactment, a tingle of excitement fills the field. Somewhere on the line, a reenactor hoots and yells, “Let’s send those Istarian rats running!”*

*A moment later, a trumpet blast signals the start of the battle. “For Istar!” yells the mercenaries’ leader, a tall half-ogre among several mounted soldiers. The mock Istarian troops assault the hill. Around you, the Vogler militia charges to meet them.*

Um, Vin notices them sum bitches are actually armed! He shouts it out to the group. Gerald retorts that "of course you would notice the cheaters."

### Real Battle of High Hill

*The unexpected sound of metal clashing on armor rings across the field, silencing laughter and melodramatic boasts. A ribbon of red splashes over the grassy hill, followed by shocked screams. Any pretense of a reenactment shatters—High Hill is the site of a true battle once more. Within moments, all around you, armed mercenaries attack unprepared villagers fighting for their lives.*

We are in a quieter sector, but then some of the guards close on us as a few arrows rain down.  Vin wastes a crossbow bolt and readies his halberd. Gerald mocks them, damaging them (Vicious Mockery). Dag erupts in a rage and rushes forward, splitting one of them in half with a great axe. 

The guards come on, clipping Dag. Vin takes one down with the halberd and smashes the last one with the butt of his spear. He eases back since Dag is in a rage. Gerald hears then sees a militia man down and crying out of assistance. He goes to help out. Dag misses the last one. 

Then it gets real.
*A hulking figure swinging a formidable battleaxe leads a band of mercenaries through the chaos. He cuts through the few remaining members of Vogler's militia as he draws closer.*

The half-ogre slaughters the one Gerald just assisted. One of his toadies stabs Gerald.

The last original guards pokes at Dag. Vin comes forward trying to get to Gerald. Gerald casts Thunderwave on a mercenary and the half-ogre. Both fail the save. It smashes the mercenary, and injures the large beast. It tosses him back a bit. Gerald withdrawals (bardic inspires Vin). Dag misses again. Merc 2 attacks Vin, but misses. Gragonis the Half-ogre runs up and nearly cuts Vin in twain. Vin feebly counters (hit with the butt end, but still). Gerald attacks with pinpoint accuracy with his rapier. The beast is feeling it. Dag, weaksauce, Inspiration and crits, closes to the real battle. The Merc misses Vin. Gragonis drops Gerald. 
Now Vin has to explain this to his father. Backstroke smashes the Merc in the jaw and then rams the halbert forward into Gragonis' throat, finishing him. Dag finishes the Merc.

The mercs flee. 

Cugel and Raven come up, bloodied. Cugel is pissed (these are her people). 

After patching up Gerald, put Gragonis head on a spear.

### Brass Crab
The surviving Merc is Svilnt Sunderlit. Learn
*Gragonis planned to kill Cudgel and take control of the Ironclad Regiment.

*Several days ago, Gragonis headed into the woods west of the mercenary camp, then returned with a considerable amount of gold.

*Afterward, Gragonis hired his most loyal mercenaries to attack the Vogler militia during the reenactment. He planned to then raid Vogler.

*The mercenary doesn’t know who gave Gragonis the gold he used to pay off the mercenaries.

*A few mercenaries remained at their camp, including Jeyev, Cudgel’s other lieutenant. The mercenary thinks the others at the camp are loyal to Cudgel—the ones Gragonis paid accompanied him to the reenactment.

Level up!













##### Navigation
[[SDQ 01 - Ispin Greenshield]] | [[Shadow of the Dragon Queen]] | [[SDQ 03 - Vogler Burns]]

