---
date: 2023-07-14
tags: Session/Dragonlance
---
# SDQ 23
**Date:** 2023-07-14
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]-

## Events

### Siege

[[Kalaman]] prepares for the siege. Refuges some to the city.  Vin has a bad feeling about this siege - they should continue on.

*The portcullis of the Trade Gate has been lowered. Dozens of anxious civilians gather outside it, banging on the gate and pleading for entry. Inside the gate, Kalaman soldiers stand with spears ready, nervously eyeing the gate and their stern captain.*

The captain tells us they can check shape. Vin is very disturbed by this information. Dag and Gerald have none of it. Gerald will cast Zone of Truth in the area. Vin and the guards are skeptical. But they let them in.

Later, there are two [[Dragonnel]] that fly in. Its [[Darrett Highwater]] and the scout [[Clystran]]. They had gotten close the flying fortress. Its riddled with tunnels with purple light. A pulp entrance. 

That evening, *The west-facing ramparts of the Trade Gate are abuzz with soldiers rushing reports in and orders out. Amid the activity stands Marshal Vendri, issuing sharp commands to an endless array of lieutenants. Every so often, the marshal’s gaze passes through the tangle of soldiers to the field beyond the walls.*

*There, thousands of soldiers in red and black raise the Dragon Army’s camp beyond the reach of Kalaman’s defenders. War machines roll into position between crimson banners bearing the Dragon Queen’s claw-like symbol. Above, dragonnels soar in rigid formations alongside the Dragon Army’s most terrifying weapon, the flying citadel. Otherworldly smokes roil from the ruined temple atop the floating island. As it drifts into place above the battlefield, reanimated corpses of ancient dragons circle the ruins, glowing with the same terrible light as the temple itself.*

![](https://i.imgur.com/GhUx2c9.png)


Vin "This city is fucked"

The Draconians do have dark/low light vision. There could be a special forces assault. 

Late that evening - *The Warrior’s Gate stands open, though its portcullis remains closed. No guards are in sight, and beside the gate, the guardroom’s door is ajar. On the other side of the portcullis, several figures wearing Dragon Army uniforms pace back and forth. As you near the gate, the portcullis begins to rise.*

The group charges into to save the day! Move to the gatehouse. Dag rushes in -there are seven men. Six in plate with two-handers. One is working the wench. The seventh is [[Lord Bakaris Uth Estide]] - fucking traitor. Dag hits one of them, in a rage. Talwin follows and tosses spike growth. The [[Dragon Army Soldier]] attack as the one turns the crank. Vin orders the dancing sword to block the portcullis going up by wedging in right at the top of the gatehouse. He then goes over and strikes one of the soldiers over Dag's shoulder. Gerald whispers, inflicting psyche damage and gives barding inspiration to Dag. 

Bakaris urges on the man opening the gate. Dag kills one of the knights. And advances on the wincher. Talwin taunts the wincher. The wincher cannot budge the wincher. The Knights are fairly ineffective in their attacks. Vin steps in, see Bakaris, and and says "I will enjoy gutting you" and lunges at him, spilling his guts. Vin follows up with a butt end of the halberd to a nearby knight. Gerald readies a fireball in case the portcullis goes up. 

Dag hits the wincher and badly injures him. Talwin hoopaks a knight. With Bakaris down, the wincher and three another knights surrender. One remaining steps forward (taking damage from the spikes) and attacks Dag, nicking him. Vin takes the last guy down. Vin orders two of them to drag Bakaris to the council chamber. Vin sternly rebukes the council for not killing this guy early, says that his son should be killed if found, and this man's head should be on a kill.

Back to the west gate: *A violet star plummets from the sky and crashes nearby, throwing up a cloud of debris. A breathless screech rises from the black-lit dust. An instant later, blackened fangs and violet flame burst forth in the form of a massive skeletal dragon.*  [[Lessor Death Dragon]] 

Talwin shoots it with his bow. Vin rushes up and hits hard with with the dragonlance. It not really a dragon, but it still does strong damage. Dag gets a while idea in his head to jump on the dragon's back. Gerald wants to drop a fireball, but too many people still around. He drops whisper instead. Its heavy damage. It pulls back and breaths. Vin holds fast (indominable). Gerald is caught in the open. 

Talwin shoots and taughts, poorly. Vin launches the sword to the dragon and shots a crossbow at it. The dragon flying up puts it in position for Dag to leap out and land on it. He is on the dragon and hits it in the wing. It comes down. Gerald rushes up, attacks and gets Dag to hit it as well. The undead dragon breaths again, clipping Vin and fully engulfing Gerald. Gerald goes down with heavy damage. It launches into the air and tries to shake Dag off his back. Dag rides it into the air. 

Tawlin heals Gerald. Vin hits with a crossbow as its 80' up. Dag takes a bit swing on it, bringing it down out of control. They come down in a heap. Dag walks away. There is a note pinned to the dragon. 

*The Dragon Queen sees you, and I am the fire in her eyes. The end comes. It is the Dragon Queen’s will.* We will put the dragon skull on the wall beside Barkais. 

Bakaris also has a note:

*Father, the Dragon Army sends its greetings and a proposition: Avoid the doom in store for Kalaman. Meet our agents at the Warrior’s Gate. Open the way, and they’ll bring you to me. I’ve found a place here and have been promised a share of the glories to come. You can have the same if you embrace the Dragon Queen’s will.*

Note: since this is Undead and not a Dragon, [[Bryan]] still has not fought a dragon. 

##### Navigation
 [[SDQ 22 - Belephaian]]| [[Shadow of the Dragon Queen]] | [[SDQ 24 - Siege of Kalaman]]

