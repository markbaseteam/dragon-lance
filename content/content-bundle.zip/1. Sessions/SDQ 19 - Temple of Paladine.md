---
date: 2023-06-02
tags: Session/Dragonlance
---
# SDQ 19 - TBD
**Date:** 2023-06-02
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
From the Lab to the Den 

*This chamber is furnished as a luxurious apartment. Its lamps and stuffed chairs look old but well maintained.*

*A hooded, crimson-robed figure steps through a door from the east and gives you a calm nod. From behind a bleached skull mask speaks a smooth voice: “Ah, welcome. Let’s get to the assessment, then.” The figure holds out a blue gem, which then shatters.*

![](https://i.imgur.com/JN9higz.png)

An [[Air Elemental]] Forms and attacks Vin! Vin somehow sidesteps a vicious blow (Lucky turned a Nat 20 to a Nat 1). Vin counters, doing modest damage. Bink recognizes the creature and tosses an Orb, turning the air cold. Dag rages and runs in the room and ... whiffs. Then hits on the second. Gerald Whispers and upsets the creature, it flees. Dag take a parting blow. The Robed Persons continues to observe. 

The Elemental comes back in but Vin stops it cold. Then hits it a few more times. Bink hits with Chill Touch. The creature is thinning. Dag is perplexed by this windy creature. Gerald Whispers again, forcing its retreat. 

The Elemental then returns and hits Dag. Vin steps forward and dissipates the elemental.

### The Masked Woman 
Its an elven woman. 

*“I am Demelin, high wizard of Onyari. You’re not the first visitors my fallen city has had in recent days. The world that forgot us has been flocking here, to the paradise of Istar. I fear that although my home has suddenly been remembered, its lessons have not.”*

See exposition dump from the prior session.

We rest up. She talks of the broken dragonlance that we have and notes a Temple of Paladine nearby.

The [[City of Lost Names]] 


### City of Lost Names
A glittering city of broken domes and jagged towers stretches before you. The nearby buildings and streets slope down into the basin of a vast, ruin-filled crater. Your vantage provides a view of the entire city, some of its broken districts scarred by fire and flooding.

Here and there, crumbled structures and massive rocks bob gently in defiance of gravity. At the city’s center, a delicate tower of sharp marble and graceful buttresses rises into the sky. It’s made all the taller by its rocky foundation, which floats off the ground.

To the southwest, the crack of shearing stone sounds from a distant temple whose grounds teem with troops. On the temple’s roof, a figure holds aloft a scepter crackling with familiar violet flame. A moment later, a skeletal dragon scales the temple and unleashes a screech that echoes across the city. It pauses before the figure, who climbs onto the undead terror’s back. Together, they rise into the air and circle the city before flying south and out of sight.

#### Temple of Paladin 
*Ahead, the water deepens into a broad pond broken by the rooflines of submerged buildings. An embankment rising just above the water is covered in a cluster of violet-leafed trees. The half-drowned ruins of a temple are visible beyond; a platinum triangle gleams on its leaning belfry.*

Several purple trees uproot and say “Each defiler you send to my gardens meets the same end. Begone!” There are dead dragon soldiers. Dag tries to persuade them, and did poorly. Gerald holds up symbol of [[Habbakuk]] and the trees slow/stop. 

![](https://i.imgur.com/offG70i.png)

*Inside the ring of trees, the ground lowers, creating a flooded bowl. Here, a roughly triangular temple rises from the water, its north side largely crumbled and its belfry leaning. The temple’s doors, half covered with water, have begun succumbing to rot, but their platinum inlays of dragons still shine.*

But there is something in the water. A [[Water Elemental]]. Bink puts Haste on Vin. Gerald holds up the symbol of [[Habbakuk]] to see if it will lets us pass. This time, it does not work. Water Elemental rushes in, attacking Vin and Gerald, engulfing them. We resist being whelmed. Dag tosses Bink aside and commands Vin attack, and he actually hits. Vin then hits 4 more times due to Haste. Bink does miss with an Orb. Gerald Whispers damage. Vin barely hits with Commanding Rally. The Elemental sprits us, with little effect.

Dag steps in with a hit. Vin tears into the Elemental, nearly taking it down. Bink mops it up. 

Open the doors to the Temple:
*Murky water covers a triangular chamber. To the east, this large hall narrows to a raised area with an altar. The north side of the building is a tangle of fallen stone and beams. The south side holds two doors.*

*Stone steps rise from the water to a dry platform bearing a triangular stone altar. Sculpted reliefs near the altar depict platinum dragons in majestic poses.*
Dag pulls out the dragonlance head and puts it on the altar. It glows and grows into a full pike!

![](https://i.imgur.com/b5fhv5r.png)

**Paladine Speaks!**
*“The last to wield this weapon was unworthy. His failure was a step along the path to the world’s destruction. But this new age needs a new hope. Use this weapon to defend the destiny mortals have chosen. Banish the shadow of the Dragon Queen with the light of this most sacred weapon. With the blessing of the gods, ye champions, reclaim the dragonlance.”*

We are refreshed and inspired!

Level Up!

##### Navigation
 [[SDQ 18 - More Memories]]| [[Shadow of the Dragon Queen]] | [[SDQ 19 - Temple of Paladine]]

