---
date: 2023-04-07
tags: Session/Dragonlance
---
# Untitled
**Date:** 2023-04-07
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
Pick up at [[Camp Carrionclay]] with a [[Draconian]] eyeing Bink. Bing drops off the wall. The [[Draconian]] leaps up to the wall and is looking for Bink. 

*Ahead, the smells of rotting fish and burning flesh hang thick in the air. A fortified camp sits atop cliffs jutting from the center of a muddy lake. The camp is ringed by immense bone spurs, with makeshift wooden walls between. A wooden palisade surrounds a camp composed of tents, huts, and a crooked watchtower. Dozens of Dragon Army soldiers keep watch around the camp.*

Bink works his way around, and almost escapes. Almost. The Draconian is going to leap down from above. Dag sees this and leaps in. Vin things its a lost cause, but comes forward. Gerald did not initially see what happened, but follows afterward. Bink tosses an icy Chromatic Orb, causing cold burns on the creature. Dag runs forward, as does Gerald. Vin looses at crossbow, glancing off him. The Sivak Draconian jumps down and brutalizes Bink, who goes down like a sack of Gnomes. 

Closing. The gate opens up, and another Sivak steps out. Then a horn from rings out. With bloody swords, it turns on Dag and cuts him. Dag rages and retaliates. A Baaz [[Draconian]] comes out of the gate and are trailing us. Gerald steps up and runs him through. The Sivak turns to dust, then makes an image of Gerald. This disturbs Gerald, but he is able to heal Bink, at least getting on his feet. Vin tries to confuse them, but confuses himself. But we are together. Another Sivak leaps onto the wall near us.

Bink, about to relive this nightmare, toss a lighning chromatic orb. Dag jumps up to swing at the Sivak, but all know White Knights Can't Jump. Gerald messes with the Baaz  (Dissonant Whispers) and calls on Dag to jump better. He heavily injures the Sivak. Start working towards the bridge. A Sivak leaps infront of Vin, but his slashes three times (reaction, 2 normal attacks) and unleases the Dancing Sword onto it, hurting it notably and knocking it prone. 

Bink toss another Orb onto the one engaged with Dag. Dag destroys the one in from of him. This throws Dag off, frightening him. Gerald Dissonant Whispers, and does Bardic Inspiration to Vin. Lost of commotion inside. Someone shouts in Common to shut the gate. Vin destroys the one in front of him, summoning Scary Vin. 

Bink comes around the corner and casts Tensers Floating Disc, getting ready for the great escape. Dag, having his own ideas, scales the wall and finds a hobgoblin in Plate and Shield. Gerald heals up Bing more. Looks like we are going up the wall. Dag drops down off the wall and mows down a [[Dragon Army Soldier]]. With Vin's help, Gerald is up on the wall and whispers scary thoughts into the hobgoblin off.  The Dragon Army Soldiers counterattack, hitting us with javelins. The Warlock stalks forward and tears into Dag, dropping him. Vin leaps from the wall and takes down a Dragon Soldier. He flings the dancing sword at the hobgoblin. The unexpected move catches him unaware and hits hard. 

Bink draws up concealment and but is unable to climb the wall. Gerald gets healing on Dag and goes to get Bink up the wall. More soldiers approach. The hobgoblin Warlord attacks the revived Dag, ripping him back down. Vin comes up to protect the fallen Dag, knocks the Warlord prone, and strikes several times. 

Bink, now up on the wall, hits the fallen Warlord with a Chromatic Orb - a critical strike! Gerald gets Dag back up again. Dag spits at the Warlord. The soldiers comes up. Dag does not even get up before Javelin pierces him. Vin goes an impressive display that only hits once against the Warlord, sigh. 

Bink drops a Fireball - it barely takes out Warlord and injures the soldiers. The Baaz comes up, but Vin takes him out at Reach. Gerald gets Dag up...again! He strikes at one of the soldiers and kills him. The Dragon Soldiers are a bit shaken by this, but one urges them on. They are ineffective. Vin jumps into the middle of them all, taking one out and injuring another. 

Bink Shatters several of them, hurting them. Dag jumps up and slays the soldier next to him. He rips the javelin out of his chest, misses, but it distracts one so that Vin can kill him (Rally). Gerald lunges forward and misses, but drops Barding Inspiration to Vin.  A soldier counterattack and hits Gerald, but misses the bloody barbarian.  The Officer comes forward, misses with Javelins, and yells at his men to attack (they get melee). Vin adjusts position, and hits the Officer for some Officer .

Bink acrobatically gets down off the wall and Shocking Grasps the soldier, but misses. Dag finishes off the soldier. Gerald Precise Strikes the one by Vin, but misses. It does leave an opening for Vin to strike the Officer. The Soldier tries to attack Vin, but utterly fails. Vin rips into the Officer. He is still up, but barely.

Bink tries to Chill Touch of the Officer, but misses. Dag gathers himself and rushes the Officer, mopping him. Vin turns his attention to the last one, killing him.
 




##### Navigation
[[SDQ 12 - Tower of Wakenreth]]SDQ 12}] | [[Shadow of the Dragon Queen]] | [[SDQ 14 - Double Dragon Day]]

