---
date: 2023-02-24
tags: Session/Dragonlance
---
# SDQ 09 - Sir Caradoc 
**Date:** 2023-02-24
**Location:** Kalaman 
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
We pick up mid-scene in the [[Kalaman]]. These were outside the city counsel chamber. We race in...its not good.

*A scene of slaughter spills across the council chamber. Several guards wearing the colors of Kalaman soldiers lie tangled amid skeletal remains in tarnished Solamnic armor. The bloody bodies of Kalaman’s council members slump in high-backed chairs and across the room’s large table. At a position of honor opposite the door, Governor Calof Miat’s body is transfixed to his chair, a gleaming longsword piercing his chest.

*Next to the governor’s body, a man in Solamnic armor rocks back in a chair. He props his booted feet on the table as he balances a scroll on one finger.*

*Noticing you, the knight stands, clears his throat, and bombastically declares, “Hail, friends, and fear not—your heroes have arrived!*

*“I, Knight Caradoc, bring word that the Knights of Solamnia are, at this very moment, en route with all manner of pomp and mustache wax and whatever else they bother with these days.” He gestures at the corpses about the room, “Do try to contain yourselves better than this lot did.”*


![](https://i.imgur.com/7k9Uonn.png)


We cannot hit [[Sir Caradoc]] because he is bald. His armor is well kept. He is pleasant as he tells us they killed everyone. His commander is off talking to a 'dusty old one' - [[Lord Soth]] maybe? Bink and Gerald has heard of this name, but he died during the [[Cataclysm]].

He is wearing the order of the Crown, but he originally was of the Rose. Vin was half sitting down when Gerald pulls his sword to put Sir Caradoc under arrest. Vin asks about the scroll - 

>People of Kalaman,
I exert my rightful claim as ruler of the province of Knightlund. Submit or flee.
Lord Loren Soth, Knight of the Rose

The writing is burned into the page.

Gerald and Dag know the following
- Knight and Ruler. Lord Soth was a Knight of Solamnia of the Order of the Rose. He ruled the province of Nightlund when it was known as Knightlund.
- Failed Redemption. The gods gave Soth the opportunity to redeem himself and prevent the Cataclysm, but he didn’t complete his quest, and the Cataclysm occurred.
- Tarnished Reputation. Soth’s failure contributed to the widespread distrust of the Knights of Solamnia.
- Cursed Castle. Soth’s fate is a mystery, but his home, [[Dargaard Keep]], is known to be a cursed, haunted ruin.

Sir Caradoc was one of Lord Soth’s men. 

### Sir Caradoc Battle
All this seems legit in Vin's eyes. So of course, Gerald attacks. How is Vin supposed to explain Geralds attack on another knight. Bink, sensing violence, casts Chromatic Orb at Sir Caradoc. Vin comes up and trips him, but is unable to continue the routine. Sir Caradoc gets up strikes Gerald but misses Vin. Tries to sneak and an attack, but the plate armor turns it aside. Gerald pierces the armor, killing him...except some spirit in trhe form of the knight of the Rose arises in his place! He lashes out at Gerald and Vin, a necrotic touch. He looks at Dag and engages him against Bink. He swings wildly. Dag fully rages and charges the spirit, sending ecoplasm everywhere. Talwin, finally seeing what really is going on, tosses an Fairy Fire at him, lighting him up but only a little.


![](https://i.imgur.com/ovrVN7o.png)

Bink tosses another Orb, but misses. Vin tears into the spirit - "you are not so tough without plate armor." But our attacks are not fulling impacting him. Gerald Dissonant Whispers at the knight, inflicting psychic damage. The disturbing words set him back, and Sir Caradoc tries to flee. The heroes tear into him, but he is still "alive". But the foul creature rushes back. He tries to get Dag to attack, but fortunately he has already burned his reaction. Sir Caradoc strikes both Dag and Gerald. Gerald is nearly down. Dag continues his rage, starting to wear the spirit down.  Talwin gets tangled up in his Hoopak, and tosses "don't be a pansy" at Gerald, healing him for a bit.

Bink tosses another Orb, shocking the spirit. Vin flails wildly, missing like 5 times. Gerald casts the disturbing word again, Caradoc goes away and stops. 

"But I must bit you adieu" and he get yanked away.

Bink stabilizes the "body" of Sir Caradoc, who was likely possessed by Sir Caradoc.

### Leedara
The singer [[Leedara]] appears. We must push on, must prevent them from attaining the secret deeper in the castle.

![](https://i.imgur.com/yHpjCz4.png)

We turn back after starting, and she is gone.

*A doorframe sculpted with somber knights stands in an alcove along this corridor. The doorframe was once sealed, but shattered bricks now lie scattered across the floor. Beyond the opening, a steep flight of stairs descends below ground. Violet light and the sound of crackling flames emanate from below.*

*Stairs descend into a stone chamber engulfed in violet flames. In the fire stand four dignified statues of Knights of Solamnia. At the east end of the room lies an antechamber before a stone double door. There, a fifth statue depicts a bison-headed warrior.*

For some reason, Vin knows its a statue of the god [[Kiri-Jolith]], god of valor. Vin and Talwin pick up an ominous vide off the violet flames. We follow a path the avoids the flames. Gerald goes to the bottom of the stairs. The flames forms the following vision

*A Knight of Solamnia saves a group of elf travelers from ogre raiders. An elf woman falls into the knight’s arms. Behind him, the silhouette of a human woman turns and fades away.*

![](https://i.imgur.com/W2ud3qj.png)

Gerald recognizes him as [[Lord Soth]]. [[Isolde]] was the elf woman.

*This long chamber blazes with violet flame. The walls are lined with alcoves, within which lie bodies wrapped in yellowed cloth. A brazier rests at the end of the hall. A section of wall has been smashed to the southwest, creating a crude tunnel to the catacombs beyond. To the southeast stands a closed stone door.*

More flames. 

*The knight from the previous vision is cast out from a group of other knights. The scene fades into a wedding between the knight and the elf woman from the previous vision.*

Continue.

*Violet flames engulf this room, dancing across walls with faded mosaics of blacksmiths forging gleaming weapons. Bars seal off alcoves to the north and south. To the west, weapons hang on the walls. A crude tunnel has been punched through the south wall there.*

The southern tunnel looks very unstable. There is one sword that is untouched by time (Dag), and a great breastplate. Cloak weaved of leaves (Talwin). 

Another scene:
*The knight receives a vision from a beam of divine light. As his wife pleads with him, he dons his armor and mounts his steed, then heads off.*

*Mosaics of knights riding armored stallions cover the walls of this room and are limned in violet flames. To the east lies a shattered stone door, and north of it gapes a tunnel that leads back to the catacomb entrance. At the west end of the room stands a statue of a rearing horse and two stone doors leading south.*

Another image forms.
*The knight’s encounters the attendants of the elf woman from the first vision. They taunt him and point back the way he came. The knight slays them and turns back home in a rage.*

As the image fades, there are two warhorse skeletons, animated. Them come forward, then vanish as they near Gerald. 

*Two heroic steeds find you worthy and agree to serve you. This charm has 2 charges. As an action, you can expend 1 charge to summon a warhorse wearing plate barding (AC 18). The warhorse serves you for 24 hours, then vanishes.*

Next area. *This chamber blazes with violet flames. In the middle of the room, steps lead up to a sleek marble monument etched with hundreds of lines of text. Doors lead from the room to the north and east.*

We are the Knights of Pastrami.
*The knight slays his wife as the world around him crumbles and burns. The knight burns as well, but he doesn’t fall. His armor fuses with his body; his eyes blaze with flames; and he becomes a terrifying, deathless figure.*

The monument is to fallen knights. In all the names, Knights Jandin and Volger.

Another room. *A statue of a saluting Knight of Solamnia stands in this room, along with two tall marble slabs etched with text. All three crackle with violet flames, and the spirit of a Knight of Solamnia kneels before one of the slabs. A door leads to the west, and a double door leads to the east.*

Another vision - A skeletal visage, it sneers and vanishes. There is another spirit here, a female kneeling knight. She acknowledges Gerald. She is [[Knight Jandin]], order of the sword.

The cataclysmic fire was only in the tomb ahead ([[Sir Sarlamir]]) , but is now spread across the crypts. Cursed Dragonlance. She lied about his role. She says for us to take the Dragonlance - perhaps we can redeem. She fades.

![[Sir Sarlamir#Salamir's Story]]

![[Knight Jandin#Knight Jandin's Shame]]

*Violet flames outline the tombs set into the walls of this spacious crypt. A heavy stone brazier sits empty near the room’s center. A sarcophagus to the north lies in pieces at the mouth of a crumbling tunnel. A wall to the southeast is similarly broken.*

*At the far end of the tomb, a flaming dais holds a sarcophagus sculpted with the image of a knight. A life-sized sculpture of a dead dragon impaled with a spear curls around the sarcophagus.*

*The violet flames waver, forming ominous images once more. The terrifying knight from the last vision steps through the wall. He approaches the brazier at the room’s center, above which roils a flaming orb. The knight holds up a scepter sculpted with screaming faces. Once touched to the ball of flame, the scepter ignites and the orb vanishes. The knight admires the flaming scepter, then points it at the ornate tomb and statue at the end of this room. Both burst into flames that spread throughout the crypt. The figure then moves to the south wall and vanishes.*

![](https://i.imgur.com/Cl9z1JF.png)

The sarcophagus cracks open and [[Sir Sarlamir]], worse for the wear, appears. 

![](https://i.imgur.com/y5igwh4.png)

### Lets finish this!
Talwin  tosses out Fairy Fire, but not real effect. Also Hunters Mark as a bonus. Gerald heals himself a bit and rushes Sir Sarlamir, striking him. Bink tosses his last Orb. Vin comes forward and drinkings a postion of healing. Sir Sarlamir misses Gerald. Dag rages and rushes forward, hitting hard. 

Talwin shots his bow, wearing on him. Also Healing Word on Gerald. Gerald attacks but misses. Bonus to Commandding Ralley, having Dag Attack. Bink tosses the cantrip Chill Touch, misses. Vin - fucking dice, all misses. The knight attacks Vin and Gerald, hitting both. Vin is hit hard. Vin cannot hit worth shit. Dag misses.

The Knight is rather talkative during the fight:
- The cursed knight, Lord Soth, calls to Sarlamir through the haunted flames of the Cataclysm.
- Lord Soth commands Sarlamir to slay those who would oppose Soth.
- Soth beckons Sarlamir to follow him north—back to the place of his dishonor, the place in the Northern Wastes Soth calls the [[City of Lost Names]].

Its a not a good time, we are weak and not hitting. Gerald whispers, disturbing the dead.   The Knight pulls back, and Vin waits for him to come in. But Vin tears into him, but is unable to stop him from coming on. He tears into Dag and Gerald. Gerald is down, and Dag finishes him.  The violet flames fade.

How will I explain this to Gerald's father?

We do recover a lancehead.

Level up (6th), note: need to add Student of War (tool or is that cartographer tools?). Select Lucky Feat, see if it changes your luck :)



##### Navigation
 [[SDQ 08 - Steel Springs]]| [[Shadow of the Dragon Queen]] | [[SDQ 10 - Northern Wastes]]

