---
date: 2023-02-17
tags: Session/Dragonlance
---
# SDQ 08 - Steel Springs
**Date:** 2023-02-17
**Location:** Steel Springs
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
Off to [[Steel Springs]] to rescue [[Darrett Highwater]]! Approximately 30 mile trek. 

*As the brook called the Inkwater comes into view, smoke rises over the tree line beyond it. Wounded Kalaman soldiers stagger from the trees, heading toward a narrow crossing that lies in your direction. Dragon Army soldiers give chase on horseback.*

Gerald rushes forward and casts Dissonant Whispers, unsettling one of the riders. Bink comes forward and drops a Web spell in front of the riders. This slow down the [[Dragon Army Soldier]] pursuers. Several toss javelins that are snagged by the web. One rider and his warhorse manages to break free from the web. We let the Kalaman soldiers  are trying to come through. A volley of arrows out of the surrounding fray rains in. Vin heroically snatches the arrow out of the air (natural 20 saves). Several Kalaman warriors fall, and Gerald is hit.

Gerald pushes past the last of the Kalaman warriors to confront the Dragon Army Soldiers. More Dissonant Whispers and Bardic Inspiration to Bink. Bink launches Firebolt, critically striking the rider stuck in the web, killing him. A soldier freed from the web recovers his warhorse.  A rider charges Gerald, attempting to crush him with his warhorse. Vin tries to unhorse the rider attacking Gerald, but the horseman is ready for it. But he Vin does wound him. 

Gerald runs the rider through with his rapier. He calls on some healing as well. Bink drops his web then launches a Cloud of Daggers on a rider. The rider comes forward but Vin strikes him with his Halberd, and unhorses the rider. He tties to toss a javelin but misses wildly. The last rider comes forward and throws a javelin at Bink, missing badly. Vin kills the unhorsed rider with the butt of his halberd, then steps around and tears the last rider off his horse. 

In the broader battle, a [[Dragonnel]] emerges and slaughters a Kalaman soldier in midair.

Gerald nearly gets control of one of the warhorses. Bink bravely comes forward to attack the last prone rider. Mopping him. 

We gather up the warhorses.

### Darrett Matures

*A dozen mounted soldiers gallop from the tree line, rushing south toward the crossing. Kalaman’s colors are visible on these soldiers’ armor, despite the dents and stains of battle. It’s easy to pick out Darrett among these riders in his distinctive Solamnic armor. Another figure sits behind Darrett, sharing his steed.*

![](https://i.imgur.com/npPY2AS.png)


Sadly, Darrett saved [[Lord Bakaris Uth Estide]]. There is a rallying point as the Dragon Army is too large and overwhelmed the force. The son,  [[Bakaris Uth Estide]],  is missing and presumed dead. Vin talkes up the soldier and calls Bakaris a coward. Its bruskly said, but all were thinking it.

Darrett sends us back to the city to let them know what happened, his is going to rendezvous with [[Marshal Vendri]].

### To Kalaman 
*A crowd mills at the gate ahead, dozens of commoners murmuring and excitedly looking past the closed portcullis. “There’s nothing to see!” shouts a guard, “Please move along.”*

The vibe is weird here. Talks of [[Knights of Solomnia]]. There appears to have been a number come to the city ahead of us. [[Sir Caradoc]] lead a retinue in about an hour ago. Their armor was not as shiny as Gerald.

*Castle Kalaman’s courtyard is largely deserted, as most of the city’s defenders remain with the troops west of the city. Near the covered cloisters leading to the city council’s conference rooms are two heavily armored Knights of Solamnia on horseback. One of them holds a banner bearing a prominent rose emblem.*

Armor is tainted with ash and rust. Something is amiss. Gerald gives the signal - there is something wrong here. They do not hardly acknowledge Gerald's overtures. Gerald grabs one of their shoulders and the knight reacts - a fight!

### False Knights 
Bink reacts quickly with a Chromatic Orb, ripping lightning into him. The lead Knight of the Rose attacks  Gerald, but he is ready and parries. The other tries to rush by Vin to attack Bink, but Vin stops him in his track. His armor, through, is tough to get through. Gerald strikes the lead Knight. 

Bink tosses Firebolt, but it goes wide. The Knight strikes Gerald, staggering him. The other Knight comes forward, stepping inside reach and grabbing towards Vin. Vin, a bit shaken by this foul undead creature, strikes at him ineffectively. Gerald misses the knight. 

Bink steps up and Shocking Grasps the Knight, destroying him. The remaining Knight tears into Gerald, tears him down. What is Vin going to tell Gerald' father, again? Vin comes up to avenge him, but only taps his armor a few times. Bink shocks him with Chromatic Orb. 

The Knight was turning towards Vin, but Bink steps up and he strikes Bink. Bink throws up Shield, but still takes a hit. Vin rips the Knight down while he is distracted by Bink. Bink gets Gerald a potion of healing, getting him up. So, at least he is not dead yet.

The foul undead knight rises. Vin is yelling at it, so it charges at Vin. Vin rips at its greaves, taking it down again. Gerald tries to recover from his near death experience (healing). 

Bink Chromatic Orb the Knight while he is down. He finishes the foul [[Wight]] in Knight's Armor. Wight Knight. get it?

These were outside the city counsel chamber. We race in...its not good.

*A scene of slaughter spills across the council chamber. Several guards wearing the colors of Kalaman soldiers lie tangled amid skeletal remains in tarnished Solamnic armor. The bloody bodies of Kalaman’s council members slump in high-backed chairs and across the room’s large table. At a position of honor opposite the door, Governor Calof Miat’s body is transfixed to his chair, a gleaming longsword piercing his chest.

*Next to the governor’s body, a man in Solamnic armor rocks back in a chair. He props his booted feet on the table as he balances a scroll on one finger.*

#### Questions for Next Time 
- Was this a
	- Fight Knights that were Wights? or
	- Fight Wights dressed as Knights?
- Is the tarnished armor 
	- Current armor that has seen heavy field action/recent neglect? or
	- Got up and walked out of a crypt
- Basically trying to figure out if these are cursed Knights (most likely) or someone is trying to sow even more discord between the populace and the Knights.

##### Navigation
 [[SDQ 07 - Wheelwatch Outpost]]| [[Shadow of the Dragon Queen]] | [[SDQ 09 - Sir Caradoc]]

