---
date: 2023-08-11
tags: Session/Dragonlance
---
# SDQ 26 -
**Date:** 2023-08-11
**Location:**
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]

## Events
* Lord Soth lurks in the ruins above. He’s using the Cataclysmic fire from Kalaman’s catacombs to control the flying citadel and reanimate dragon skeletons buried in the flying island’s foundations.
* If the characters can quell the Cataclysmic fire, the Undead dragons will be destroyed and the flying citadel will fall.
* Leedara isn’t certain how to quell the Cataclysmic fire. The flames were created by the gods, so it stands that the power of the gods could extinguish them.
* Lord Soth is a peerless foe. The characters won’t be able to stand against him in battle.
* Hidden somewhere in the chambers ahead is an elven relic known as the mirror of reflected pasts (see appendix A). Those who view the mirror see glimpses of their past.
* Leedara believes the mirror can distract Soth, giving the characters a chance to extinguish the Cataclysmic fire.

Rotate the statue of [[Takhisis]] so it points straight south. This opens a door.

*Crumbled frescoes lie along the walls of this dilapidated sanctuary. A twenty-foot-tall statue of the Dragon Queen dominates the west end of the room, with smaller statues arrayed behind it. Coins and other valuables lie strewn about this partially collapsed chamber. Among them is a sizable mirror with an intact pane of black glass.*

The sword and mirror are magic, and several potions.

Moving on, *From the top of the stairs, a shattered corridor runs to the south. The ancient walls to the west and east are made of crumbling stone, and flickering violet light shines through gaps in the east wall. At the south end of the hall, another stairway rises into one of the ruin’s corner towers. An unfamiliar soldier in Kalaman’s armor stands there. With a look of mild surprise, she notices you. “Oh. You,” she says. “You could be helpful. Come on.” With that, she turns and heads up the far stairs.*

*This dilapidated room was clearly once a shrine, and its walls are covered in carvings of robed figures gathered beneath a large black moon. Recesses with lit black candles and melted wax cover the walls at even intervals. Simple doors lead to the north and east.*

[[Sir Caradoc]] is in another form (one who killed the Council). He thinks [[Lord Soth]] is misaligned. This is distracting him from attacking the [[Knights of Solomnia]]. We distract Soth and he takes the Citadel away. 

* Caradoc believes Soth’s alliance with the Dragon Army is folly, distracting him from taking revenge against the Knights of Solamnia.
* Caradoc wants to take control of the flying citadel. He promises to leave Kalaman if the characters help him do so. 
* Soth is higher up in the ruins, where he controls the flying citadel using a throne linked to the Cataclysmic fire holding the citadel aloft.
* Soth is fantastically powerful. Caradoc urges the characters to find a way to distract him or otherwise undermine him without fighting.
* Wersten Kern, Soth’s standard bearer, guards the brazier containing the Cataclysmic fire. She’s loyal to Soth and will have to be disposed of as well.

[[Wersten Kern]].

Its the best option among a set of bad options. We will distract Soth, then deal with Caradoc later.

*A hulking minotaur is carved in bas-relief on this shrine’s west wall. Scorch marks cover the floors and walls. Doors lead to the north and west.*

A fight ensues. Dag rages but swings wildly. Gerald steps forward and whispers, inflicting damage. Talwin Ice Knife for little effect. Vin steps in and chips away at one of the skeletal knight. Caradoc does a whisper (Commanding Rally ) for Dag, it misses of course. Dag chops at the first Knight, and tosses a commanding Rally to Vin, who Crits and trips the second knight. Gerald working on the second knight as well. The fight continues, but the knights are not that effective. Vin finishes off the knight, and sends the dancing sword over to the first knight. Ther others do a bit of damage, but heroic Vin finishes the other skeletal knight. 

### Soth 
*Sections of this chamber’s walls have fallen, revealing both the open interior of the temple and the dark clouds surrounding the flying island beyond. Overlooking the violet flame at the temple’s heart below, this chamber holds a crude throne made of broken marble. Veins of pulsing violet light—the same shade as the flames below—pulse through the stone. A still figure in charred armor sits on the throne, glowing red eyes staring from his closed, crown-like helm. His charred breastplate bears a black rose emblem.*

*The interior of this mighty temple has been hollowed out, its roof and interior walls reduced to rubble, creating one great chamber. At the north of the ruins stands a menacing statue of the Dragon Queen with her five snarling draconic heads. Above the statue, deteriorating stone reveals a shadowy chamber in the wall forty feet up.*

*At the chamber’s center, a massive brazier—easily ten feet tall and thirty feet across—roils with violet flames. A crude iron scaffold surrounds it, with uneven stairs climbing to a platform surrounding the lip of the brazier. Four supports crowned by blazing violet flames levitate around the scaffold, holding it aloft. A figure in blackened armor stands atop the scaffold, bearing a pike fluttering with tattered cloth.*

![](https://i.imgur.com/SgBm7gD.png)

The mirror seems to work on Soth - he is stunned. Kern is coming on over a magical arch they created. We attempt to stave Kern off. Caradoc gets the help from Soth. Kern waves away Talwin's spike growth. Vin tears into Kern. Does not kill Kern, but does heavy damage. Caradoc tosses off the helm in a rage and attacks Vin. He will regret this. Dag does more to Kern, but they are still up! Kern flees from a Whisper. Dag hits her and by all right should kill her, but she is still up. She curses us. 

Talwin bypasses her evil protections and slayers her. Vin turns on Caradoc and inflicts some damage. Caradoc does hit Vin and commands Vin to hit Dag, which he does with ease. The Citadel is starting to come out of control. Gerald chugs a potion and has Dag attack, and he hits! Caradoc is heavily damaged. Heals on Dag.  

Talwain heals on Dag. Vin hammers on him, and knocks him down. He rolls back up and attacks ineffectively. Dag tears into him, ripping him down. A shadow erupts out of the body and flees. 

The Citadel is heavily listing. We grab the helm to flee. Escape from the front of the castle. Catch [[Dragonnel]] before it crashes. We escape, Hollywood style. This breaks the back of the Dragon Army. We are heroes!
##### Navigation
[[SDQ 25 - Storming the Citadel]] | [[Shadow of the Dragon Queen]] | 

