---
date: 2023-06-09
tags: Session/Dragonlance
---
SDQ 20 - The Manor
**Date:** 2023-06-09
**Location:** City of Lost Names
## PCs
- [[Vin Messere]] - [[Rees, Jeffrey]]
- [[Gerald Wayland]] - [[Daymude, Mark]]
- [[Talwin Lightfoot]] - [[Ippolito, Paul]]
- [[Dag Greywolf]] - [[Bryan]]
- [[Binkelmore Nickerboker]] - [[Lonnie]] 

## Events
Vin has the [[Dragonlance]] due to his build.

*The last to wield this weapon was unworthy. His failure was a step along the path to the world’s destruction. But this new age needs a new hope. Use this weapon to defend the destiny mortals have chosen. Banish the shadow of the Dragon Queen with the light of this most sacred weapon. With the blessing of the gods, ye champions, reclaim the dragonlance.*

*“Are you okay?!” Rookledust asks, then she rapidly continues. “We just saw something come over the cliffs—a gods-cursed dragon skeleton! We’re retreating, and the Dragon Armies are following. We’ll keep them drawn out as long as we can. See if you can get at whoever’s in charge in there!”*

Feeling our oats, we go to the Temple of [[Takhisis]].  Check that - too many bad guys. We are going to the Manor. 

### Manor 
*At the end of a row of ruins stands a partially intact manor. Most of the manor’s east side has collapsed, but the rest of the house has been cleared and made serviceable. In the southeast corner, an attached carriage house stands next to the front entrance.*

There are four Kapak [[Draconian]]s and an occasional patrol of [[Dragon Army Soldier]]s. Plotting our entry to the back (there is only one) is the first thought. Bink sneaks up so that he can use a power to swap back with Dag, and Dag will take him out. Talwin sneaks as well. They get near the draconian. They overhear talk of someone touched by the gods down south. Dag rushes in and does heavy damage to the foul creature. Gerald and Vin rush from afar. Talwin Taunts. Vin rushes forward and flings his Dancing Sword at the creature. It slices into his throat and kills it. Dag, in rage, crashes in the door. Gerald follows and sees a Bozak draconian. His Whisper causes the Bozak to flee. Talwin Fairie Fires them, effecting the Bozak. Dag rushes in and tosses javelins at one of the draconians, severely injuring it. Bink tosses Haste on Vin, who rushes in and kills one of the soldiers whilst sending the Dancing Sword at the Bozak. The soldiers attack Vin, but generally miss, with Vin stopping one in his tracks. One casts Web, but Vin dodges. Another casts Lighning Bolt (as a ranged power). With a bit of Luck, Vin dodges out of the way (Lucky Edge).

Bink mosies into the room and fireball. That Bozak has a really bad day. Two Draconians down. A Kapak from outside comes in. Gerald Thunderwaves the soldiers and Inspires Vin. Talwin hoopaks the Kapak. He also Taunts him. Dag rushes the Kapak, doing 54 damage. Vin finishes a soldier and tears into the second Bozak. A [[Hobgoblin]] named Yurl with a great sword bursts in attacks Dag with minor damage. The soldier attacks and Vin and Gerald, and Vin sneaks in a cheap shot. Another solders comes and tosses javelins, one hitting Gerald. But in general are poor aims. Bozek tries to web Gerald and Vin, but is ineffective.

Bink Fireballs the dragon soldiers all clumped together, heavily wounding most of them. Then their leader ([[Captain Hask]]), a golden draconian, comes down the stairs. Gerald Whispers, encouraging him to leave. It works! Then commands Dag to attack - nicks him. Talwin drops Spike Growth on the solders. Somehow, that Captain is back. Dag attacks Yurl, crushes his skull and command Gerald to attack.  Vin finishes the Bozak and attacks Hask, heavily injuring him. The soldier attacks Vin and Gerald, hurting Gerald. Vin retaliates. The soldiers try not to move and toss javelins. One does hit Dag. One soldier does move and throws at Tawlin, hitting him but he keeps his power up. One hits Gerald and Vin, with modest damage. Another moves through the spikes and ... dies! 

Bink tosses an Orb at Hask, hitting him with lightning. The Kapaks attack Dag, nicking him. Gerald Precise strikes at Hask, hitting him. He crits and kills him! Then a bit of healing. Talwin casts Earth Tremor on the soldiers. He kills the weakened soldiers. Dag nearly decapitates one of them, and back swing to finishes him. Vin kills a few more (soldier, Kapak), and we mop up the rest.

*A fire burns in the marble fireplace of this large salon. The room’s tall windows have been boarded over, and its rotted furnishings have been shoved aside to make room for mismatched and gouged dining tables. On the north side of the room, a curving stairwell rises between the back door and a hallway. On the south side, one door leads to the south and another to the east.*

As we search:
*This pantry is crammed with supplies, ranging from hardtack and clothing to weapons and armor. Although most of the crates are made of rough wood, a metal one is etched with designs of blue dragons.*
Its trapped, and there are Sapphires and 3 javelins (likely those one that have a lightning bolt javelin). 

**** Upstairs
*Most of this library’s books have fallen to rot, but two desks beneath tall windows stand covered in papers and candles. One door leads to a room to the west, and another opens to the hallway to the north.*
Bink scans the papers and learns:
- The commander of the Red Dragon Army, [[Dragon Highmaster Kansaldi Fire-Eyes]], isn’t in the City of Lost Names. She remained with the bulk of the army near Kalaman.
- The commanders [[Belephaion]] and [[Lohezet]] lead this contingent of the Red Dragon Army. They don’t get along.
- Belephaion is a terrifying fanatic who claims to speak for the Dragon Queen herself. Even Kansaldi listens to his advice.
- Lohezet is a scheming, black-robed Mage of High Sorcery. He’s obsessed with ancient magic and venomous beasts, and his research led the Dragon Army to the City of Lost Names.
- Belephaion and Lohezet have worked at the tower called the Threshold of the Heavens for days, preparing to reactivate the city’s ancient flying magic.
- The clerk knows nothing of Lord Soth and prefers it that way. The death knight supposedly receives orders directly from the Dragon Queen.

[[Captain Hask]] room:
*This bedroom is well preserved, with a four-poster bed, a desk, and a small chest. A round turret to the southeast—with glass intact in its windows—provides a panoramic view of the neighborhood’s wreckage. A door leads to a room to the east, and another door opens to the hallway to the north.*

* Two Dragon Army leaders, Belephaion and Lohezet, work at the Threshold of the Heavens.
* The passphrase to gain entrance to the Threshold of the Heavens is “By her will: the world.”
* Dragon Army engineers have completed the majority of their work, shoring up the foundations of the city’s most intact districts.

There was a key on Hask, and a chest in the room. Inside 200 lb sack of silver (10k coin). And a Pearl of Power. 






##### Navigation
 [[SDQ 18 - More Memories]]| [[Shadow of the Dragon Queen]] | [[SDQ 21 - Threshold of the Heavens]] 

