---
tags: Location/Dragonlance
---

# The Wrecker’s Edge


## Description
In the [[Northern Wastes]], lies at the southeastern shore of the wastes.

### Wrecker’s Edge


### NPCs