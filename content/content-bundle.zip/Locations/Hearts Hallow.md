---
tags: Location/Dragonlance
---

# The Hearts Hallow


## Description
![](https://i.imgur.com/NCsS5Fc.jpg)

### Hearts Hallow
[[Northern Wastes]] 

The whole town just has a scavenger feel to it.

Ends Odds - Curio shop by a dwarf

### NPCs
- [[Kennah Lightfoot]] 
- [[Clystran]] 
- [[Nesra]], the mayor, who is a Bronze Dragon