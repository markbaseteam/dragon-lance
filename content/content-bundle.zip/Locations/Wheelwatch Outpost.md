---
tags: Location/Dragonlance
---

# The Wheelwatch Outpost


## Description

### Wheelwatch Outpost
25 Miles southeast of [[Kalaman]] 

### NPCs