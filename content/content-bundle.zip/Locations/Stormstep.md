---
tags: Location/Dragonlance
---

# The Stormstep


## Description


### Stormstep
*Ahead, a pale stone tower juts from the rust-colored landscape. Carved with the likenesses of a thousand elven warriors, the tower has relatively intact lower levels, but as it climbs toward its eighty-foot height, the upper levels deteriorate. Rather than falling, the crumbling stone hangs in the air, the tower’s disintegration frozen unnaturally. A rusty iron double door at the tower’s base hangs ajar.*

### NPCs