---
tags: Location/Dragonlance
---

# The Northern Wastes


## Description
![](https://i.imgur.com/ZxyphWa.jpg)

![](https://i.imgur.com/j3Ysc3s.jpg)


### Northern Wastes
Landed at A. Elves base camp at B.

D - [[Sunward Fortress]] 

Note that canyons are subject to dangerous flash floods.

![[Deepdraught]]


![[Stormstep]]
### NPCs