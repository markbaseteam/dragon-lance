---
tags: Location/Dragonlance
---

# The Silvanesti
Land of the elves.

Fallen to the Dragonarmies. 

## Description
![](https://i.imgur.com/ovAAZhD.png)

### Silvanesti


### NPCs
- [[Dalamar]]
- [[Zhelsuel]] 