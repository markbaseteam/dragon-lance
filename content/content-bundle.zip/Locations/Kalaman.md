---
tags: Location/Dragonlance
---

# The Kalaman


## Description
*The walled city of Kalaman rises in the distance, spreading across the southern shore of a wide bay. Ships sail to and from the city’s walled harbor, their courses lit by a pair of towering beacons.*

*Statues of titanic soldiers line Kalaman’s mighty walls. These ancient stone knights stare into the distance, daring invaders to dash themselves against defenses that withstood even the Cataclysm. A disorganized neighborhood of tents and ramshackle structures lines the road to the city’s nearest gate, where soldiers in blue-and-yellow uniforms question all who enter.*

![](https://i.imgur.com/CREcSAI.jpg)

### Kalaman

#### Castle Kalaman
*Even if the imposing Castle Kalaman didn’t stand atop hundred-foot cliffs, it would still tower over every other structure in the city. The path to it rises up the cliffside, overlooked by gigantic statues matching those that line the city’s walls. At the path’s end, guards stand before an open gate.*

### NPCs