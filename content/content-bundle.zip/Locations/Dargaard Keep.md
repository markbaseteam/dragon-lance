---
tags: Location/Dragonlance
---

# The Dargaard Keep


## Description
Home of [[Lord Soth]] 

### Dargaard Keep


### NPCs