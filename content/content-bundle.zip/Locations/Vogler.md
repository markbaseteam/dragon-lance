---
tags: Location/Dragonlance
---

# The City of Vogler


## Description


![](https://i.imgur.com/dPNzjrn.jpg)

### Volger
A city in [[Solamnia]]. 

### Locations 

#### Brass Crab


#### Thornwall Keep

### NPCs
- [[Bakaris Uth Estide]] 
- [[Becklin Uth Viharin]] 
- [[Ispin Greenshield]] 