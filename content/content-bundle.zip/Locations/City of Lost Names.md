---
tags: Location/Dragonlance
---

# The City of Lost Names


## Description
![](https://i.imgur.com/gSrD4TV.jpg)

![](https://i.imgur.com/J9ary0T.jpg)


![](https://i.imgur.com/tQl2aMq.png)


### City of Lost Names
A glittering city of broken domes and jagged towers stretches before you. The nearby buildings and streets slope down into the basin of a vast, ruin-filled crater. Your vantage provides a view of the entire city, some of its broken districts scarred by fire and flooding.

Here and there, crumbled structures and massive rocks bob gently in defiance of gravity. At the city’s center, a delicate tower of sharp marble and graceful buttresses rises into the sky. It’s made all the taller by its rocky foundation, which floats off the ground.

Note that [[Lord Soth]] just left on his Undead Dragon. 



### NPCs