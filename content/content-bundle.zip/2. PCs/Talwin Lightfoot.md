---
tags: PC/Dragonlance, Creature/Humanoid/Kender 
---

[[Ippolito, Paul]]
Kender and a Druid/Ranger

Kenders are known for their curiosity, wit, and mischievousness, and as a Druid/Ranger, Talwin brings a unique blend of nature magic and combat skills to the table.