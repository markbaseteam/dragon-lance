---
alaises: Vin Blackaxe
tags: PC/Dragonlance, Creature/Humanoid/Human 
---

#### Handy Cheatsheet
https://crobi.github.io/dnd5e-quickref/preview/quickref.html

#### Build Notes
https://arcaneeye.com/class-guides/battle-master-5e-guide/

Base Number of Attacks: 3
#### Combat Superiority Maneuvers (Short Rest)
- [x] 
- [x] 
- [ ] 
- [ ] 
- [ ] 

#### Lucky (either have advantage or instill disadvantage) (Long Rest)
- [x] 
- [x] 
- [x] 

#### Action Surge/ Second Wind / Class Features
- [x] Action Surge - One additional Action (Short Rest)
- [ ] Second Wind (1d10+Lvl) (Short Rest)
- [x] Indomitable (reroll a Save) (Long Rest)

#### Bardic Inspiration
- [x] 

####  Target Save for Superiority 
8 + Prof +  Strength: 8 + 3 + 5 = 16 

### Action Economy (Action, Bonus Action, Reaction)

| Action                      | Bonus                         | Reaction                         | Free                                   |
| --------------------------- | ----------------------------- | -------------------------------- | -------------------------------------- |
| Melee Attack (Extra Attack) | Butt Attack (Pole Arm Master) | Opportunity Attack               | Movement                               |
| Disengage                   |                               | Readied Action Triggered         | Interaction with Object or Environment |
| Grapple /Escape             |                               | Enter Reach (OA, Polearm Master) | Action Surge (Long Rest)               |
| Dodge (Defend)              |                               | Enemy Disengage (Sentinel)       | Second Wind (Long Rest)                |
| Hide                        |                               | Enemy Attacks Another (Sentinel) | Precision Attack (Superiority)         |
| Search                      |                               | Riposte (Superiority)            | Trip (Superiority)                     |
| Help (grant advantage)      |                               |                                  | Lucky (Long Rest)                      |
| Ready                       |                               |                                  | Maneuver Attack (Superiority)          |
| Dash                        |                               |                                  | Menacing Attack (Superiority)          |
| Use an Object               |                               |                                  | Evasive Footwork (Superiority)         |
|                             |                               |                                  | Lunging Attack (Superiority)                                       |


### Movement 
- Move 30' (5' per 5')
- Stand Up cost 15' (half)
- Grapple Move 15' (half)
- Climb 15' (10' per 5')
- High Jump 5' per 5'
- Long Sump 5' per 5'
- Swim 15' (10' per 5')
- Drop Prone 0'
- Crawl 15' (10' per 5')
- Difficult Terrain 15' (+5' per 5')


## Cool Description
A warrior stands tall, wielding a formidable halberd. The weapon, a combination of an axe and a spear, glints menacingly in the sunlight. The warrior's armor is adorned with intricate designs, a testament to the skill of the blacksmith who crafted it. The warrior's eyes are sharp, scanning the battlefield with a fierce determination. With a fierce roar, the warrior charges forward, ready to defend their land and people with the deadly precision of their halberd. The enemies tremble at the sight of this formidable warrior, knowing that they are facing a true master of their craft. Their halberd is not just a weapon, but an extension of their very being, a symbol of their strength and skill. This warrior is not just a fighter, they are a force to be reckoned with, a true warrior.

![](https://i.imgur.com/ptf0wRs.jpg)

![](https://i.imgur.com/sVJCEBa.png)

![](https://i.imgur.com/CIa75bz.png)


[[Rees, Jeffrey]]

Kill Count 
[[Draconian]] 
	Baaz (stone) - 7
	Kapak (acid) - 2 
	
Mercenary -1
Half-Ogre Mercenary - 1
[[Dragon Army Soldier]] - 8 (2 mop set ups)
	Officer  (1 mop set up)
[[Goblin]] - 3
[[Spider, Giant]] - 4
[[Wight]] -1

Named:
- [[Fewmaster Gholcag]] 
- [[Sir Caradoc]] - assist
- [[Virruza]] - assist
- [[Belephaion]] - a [[Dragon, Blue]]
