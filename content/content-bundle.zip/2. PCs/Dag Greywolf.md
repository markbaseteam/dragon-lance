---
tags: PC/Dragonlance, Creature/Humanoid/Human
---
[[Bryan]]'s PC'
Formally known as Dag Wood.

Barbarian Knight. Trying to 'live better'
Eastern [[Solamnia]] 

![](https://i.imgur.com/IRAFGkg.png)
