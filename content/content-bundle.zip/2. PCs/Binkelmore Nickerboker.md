---
aliases: Bink
tags: PC/Dragonlance, Creature/Humanoid/Gnome
Creature_Type: Humanoid/Gnome
---
# Blinkelmore Nickerboker

```ad-danger
Cool description
```

Writeup
[[Lonnie]] 
Insert Cool Pic

Wizard. But loner.
"I Wiz Alone"
"I cannot Wiz while you watch"

Thank you for the information about Bink. Gnomes are known for their love of tinkering and their mischievous personalities, making them a fun addition to any adventuring party. As a wizard, Bink brings a mastery of magic to the group, making him a valuable asset in their battles and adventures.
