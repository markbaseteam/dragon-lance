---
tags: PC/Dragonlance, Creature/Humanoid/Human 
---

[[Daymude, Mark]]
Squire in the Knights of Solamnia. He just become a full Knight, Order of the Crown.

![](https://i.imgur.com/9zOhw07.png)
