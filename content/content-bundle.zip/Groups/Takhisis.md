---
Aliases: Dragon Queen
Tags: God/Dragonlance/Takhisis
---

Eeeeevil Goddess.