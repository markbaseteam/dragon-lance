---
tags: Group/Mercenary
---
In [[Vogler]] , 

## Members
Leader -  [[Cudgel Ironsmile]].
[[Jeyev Veldrews]] 


### Disloyal
Gragonis


